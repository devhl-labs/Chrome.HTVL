"use strict";

var wrapper;
var lnk;
var divContainer = document.getElementsByClassName('option-filters')[0];
var br;

setSyncDefaults(start);

function start(){
//$(document).ready(function(){
     if(debug) console.log('document is ready, creating buttons');
     setTimer();
     createOptionsButton();
     createLoadingButton();
     createHideChannelsButton();
     createBrandingButton();
     createMostWatchedChannelsButton();
     createRecordingShowsButton();
     createLastChannelsButton();
     createFavoritesButton();
     createHdButton();
     createRemoveFavoritesButton();
     createPrintSyncButton();
     createClearSyncButton();
        
     if(customFiltersActive()){
          var hr = document.createElement('hr');
          divContainer.appendChild(hr);
          createSportsButtons();
     }
     toggleDefaultFilters();
     
     
     watchChannelListener();
     createMutationObserver();
     
     
     
     
     var $filters = $('[data-filter]');
     $filters.bind(
          "click", function(){
               $('.selected').removeClass('selected');
               $('#lnkHideChannels').text('Hide Channels');
               $('#lnkHideChannels').css('background', '');
               $('.channel').hide();
               var filter = $(this).attr('data-filter');
               $('.' + filter + '.ShowMe').show();
               $('.channels').css({'min-height': '1000px'});
               $('[data-filter="' + $(this).attr('data-filter') + '"]');
          }
     );

//     $('.button.filter.hd').bind(
//          "click", function(){
//               //localStorage['htvlView'] = '#lnkHd';
//               //$('#lnkHideChannels').css('background', '');
//          }
//     );
//     $('.button.filter.movies').bind(
//          "click", function(){
//               localStorage['htvlView'] = '#lnkMovies';
//          }
//     );
//     $('.button.filter.sports').bind(
//          "click", function(){
//               localStorage['htvlView'] = '#lnkSports';
//          }
//     );
//     $('.button.filter.kids').bind(
//          "click", function(){
//               localStorage['htvlView'] = '#lnkKids';
//          }
//     ); 
     
     
     
     
     chrome.runtime.sendMessage({version: 1.0}, 
          function(response) {
               if(response.farewell) alert('Thank you for installing htvl.\nNotice the options button on the right.\nThat is how you configure this extension.\nExisting users will have to recreate custom filters.\nSorry for the inconvienience.');
          }
     );
     
     
     
     
     
     if(debug) console.log('end document ready');
//});
}

