//previous version that is no longer published, no longer used
chrome.management.setEnabled('gnbeokkohplojcckboakfdippdeclilo', false);


chrome.runtime.onMessage.addListener(
     function(request, sender, sendResponse) {
          var boo = false;
          if(!localStorage['htvlVersion']) {
               localStorage['htvlVersion'] = 1.0;
               boo = true;
          }
          if(localStorage['htvlVersion'] != request.version){
               localStorage['htvlVersion'] = request.version
               boo = true;
          }
          if (boo) sendResponse({farewell: "goodbye"});
     }
);

