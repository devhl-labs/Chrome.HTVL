if(!localStorage['xfinityHide']){localStorage['xfinityHide']='';}

//Create the remove favorites button
var lnkRemoveFavs = document.createElement('a');
lnkRemoveFavs.innerHTML = 'Remove All Favorites';
lnkRemoveFavs.setAttribute('class',  'button filter');
var divFilters = document.getElementsByClassName('option-filters')[0];
divFilters.appendChild(lnkRemoveFavs);

lnkRemoveFavs.onclick=function(){
	var style;
	var display = '';
	var lnkFavorites = document.getElementsByClassName('hover-remove');
	
	try{
		for (var i = 0; i < lnkFavorites.length; i++){
			style= window.getComputedStyle(lnkFavorites[i]);
			display=style.getPropertyValue('display');
			if(display=='block'){
				lnkFavorites[i].click();
			}
		}
	}catch(err){
		console.log(err);
	}
}

//create the Hide Channels button
var lnkHide = document.createElement('a');
lnkHide.innerHTML = 'Hide Channels'
lnkHide.setAttribute('class',  'button filter');
divFilters.appendChild(lnkHide);

lnkHide.onclick = function(){
	var divChannels = document.getElementsByClassName('channels')[0].children;
	if($('.hideChannels').length==0){	
		for(var i=2; i < divChannels.length; i++){
			try{
					var elem=divChannels[i].childNodes[3];
					elem.appendChild(createHideMe(elem.parentNode));
					elem.appendChild(createUnHide(elem.parentNode));
					elem.setAttribute("style", "width: 285px;");
			}catch(err){
				console.log(err);
			}
		}
	}
	hideRows();
}



//Create the Show Hidden Channels button
var lnkShowHidden = document.createElement('a');
lnkShowHidden.innerHTML='Show Hidden';
lnkShowHidden.setAttribute('class', 'button filter');
divFilters.appendChild(lnkShowHidden);
lnkShowHidden.onclick=function(){
	$('.channel').show();
}


function createHideMe(parent){
	var lnkHideChannel=document.createElement('a');
	lnkHideChannel.innerHTML = 'Hide Me!';
	lnkHideChannel.setAttribute('style', 'display: block; width: 41px;');
	lnkHideChannel.setAttribute('class', 'hideChannels');
	//lnkHideChannel.href="#";
	lnkHideChannel.onclick=function(){
		//parent.setAttribute('style', 'display: none;');
		//parent.parentNode.setAttribute('style', 'color: #929292;');
		parent.childNodes[3].setAttribute('style', 'background-color: DarkGray');
		parent.setAttribute('style', 'background-color: DarkGray');
		parent.parentNode.setAttribute('style', 'background-color: DarkGray');
		if(!localStorage['xfinityHide']){localStorage['xfinityHide']='';}
		localStorage['xfinityHide']+=parent.id + ";";
	};

	return lnkHideChannel;
}

function createUnHide(parent){
	var lnkUnHide=document.createElement('a');
	//this is an issue, not sure why
	//lnkUnHide.innerHTML = 'Unhide Me';
	lnkUnHide.setAttribute('style', 'display: block; width: 41px;');
	lnkUnHide.setAttribute('class', 'unHideChannels');
	lnkUnHide.href="#";
	lnkUnHide.onclick=function(){
		if(!localStorage['xfinityHide']){localStorage['xfinityHide']='';}
		localStorage['xfinityHide']=localStorage['xfinityHide'].replace(parent.id + ";", '');
	};

	return lnkUnHide;
}


function hideRows(){
	if(localStorage['xfinityHide']){
		var arr = localStorage['xfinityHide'].split(';');
		var arrLength = arr.length;
		for (var i = 0; i < arrLength; i++) {
			$('#' + arr[i]).hide();
		}
	}
}
