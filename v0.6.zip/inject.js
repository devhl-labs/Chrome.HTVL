if(!localStorage['xfinityHide']){localStorage['xfinityHide']='';}

//Create the remove favorites button
var lnkRemoveFavs = document.createElement('a');
lnkRemoveFavs.innerHTML = 'Remove All Favorites';
lnkRemoveFavs.setAttribute('class',  'button filter');
var divFilters = document.getElementsByClassName('option-filters')[0];
divFilters.appendChild(lnkRemoveFavs);

lnkRemoveFavs.onclick=function(){
	var style;
	var display = '';
	var lnkFavorites = document.getElementsByClassName('hover-remove');
	
	try{
		for (var i = 0; i < lnkFavorites.length; i++){
			style= window.getComputedStyle(lnkFavorites[i]);
			display=style.getPropertyValue('display');
			if(display=='block'){
				lnkFavorites[i].click();
			}
		}
	}catch(err){
		console.log(err);
	}
}

//create the Hide Channels button
var lnkHide = document.createElement('a');
lnkHide.id='lnkHideMe';
lnkHide.innerHTML = 'Hide Channels'
lnkHide.setAttribute('class',  'button filter');
divFilters.appendChild(lnkHide);

lnkHide.onclick = function(){
	//I would like to do most of the below code when the page is finished loading
	//but the dom is finished loading before the channels
	//running the below on the button press is a way of making sure all of the 
	//channels are loaded completely.
	document.getElementById('lnkShowMe').click();
	var divChannels = document.getElementsByClassName('channels')[0].children;
	if($('.hideChannels').length==0){	
		for(var i=2; i < divChannels.length; i++){
			try{
					var elem=divChannels[i].childNodes[3];
					elem.appendChild(createHideMe(elem.parentNode));
					elem.appendChild(createUnHide(elem.parentNode));
					var x = elem.parentNode.id;
					if(localStorage['xfinityHide'].indexOf(x)>-1){
						elem.setAttribute('style', 'width: 283px; background-color: DarkGray;');
						elem.parentNode.className=elem.parentNode.className + " HideMe";
					}else{
						elem.setAttribute('style', 'width: 283px;');
						elem.parentNode.className=elem.parentNode.className + " ShowMe";
					}
			}catch(err){
				console.log(err);
			}
		}
		$('.hover-add').css('border-left', '0px');
		$('.hover-remove').css('border-left', '0px');
		$('.channels').css({'min-height': '1000px'});
		$('.viewport').css({'min=height': '1000px'});
		//This next bit has to be done here
		//I suspect it is because Chrome is asynchronous,
		//so the element does not exist in the DOM by the time
		//createUnHideMe runs
		for(i=0; i < $('.unHideChannels').length; i++){
			$('.unHideChannels')[i].innerHTML='Unhide Me!';
		}
	}
	hideRows();

}

//Create the Show Hidden Channels button
var lnkShowHidden = document.createElement('a');
lnkShowHidden.innerHTML='Show Hidden';
lnkShowHidden.id='lnkShowMe';
lnkShowHidden.setAttribute('class', 'button filter');
divFilters.appendChild(lnkShowHidden);
lnkShowHidden.onclick=function(){
	$('.channel').show();
}


//create filters
var divFilterCategory = document.getElementsByClassName('option-filters')[1];
var lnkCustomFilter;
//var arrTerms = new Array();
if(!localStorage['xfinityFilters']){localStorage['xfinityFilters']=
'MLB::MLB Baseball::MLB Tonight;' +
'NBA::NBA Playoff;' +
'NCAAM::College Basketball;' +
'NHL::Stanley Cup Playoff;' +
'NFL::NFL Total Access::NFL Draft;'
;}

var xfinityFilters=localStorage['xfinityFilters'];
var arrFilters=localStorage['xfinityFilters'].split(';');
for(i=0; i< arrFilters.length; i++){
	var arrFilter=arrFilters[i].split('::');
	for(var x=0; x < arrFilter.length; x++){
		if(x==0){
			lnkCustomFilter=document.createElement('a');
			lnkCustomFilter.innerHTML=arrFilter[x];
			lnkCustomFilter.setAttribute('class', 'button filter');
			lnkCustomFilter.onclick=function(){
				if($('.' + this.innerHTML.replace(' ','')).length>0){
					//this part only runs if the user has already selected 
					//this particular filter
					//avoids unneeded cpu cycles
					$('.' + this.innerHTML.replace(' ','')).show();
					$('.no' + this.innerHTML.replace(' ','')).hide();
					$('.HideMe').hide();
				}else{
					//the user has not selected this filter yet
					//classes still need to be added to channels
					document.getElementById('lnkShowMe').click();
					document.getElementById('lnkHideMe').click();				
					var arrFilters=localStorage['xfinityFilters'].split(';');
					for(var a=0; a < arrFilters.length; a++){
						if(arrFilters[a].substring(0, this.innerHTML.length)==this.innerHTML){
							//at this point, arrFilters[a] is the entire string
							//example NHL::Stanley Cup Playoffs; Some other hockey value
							arrFilters[a]=arrFilters[a].substring(this.innerHTML.length+2);
							//arrFilters[a]=Stanley Cup Playoffs; Some other hockey value
							var arrFilterVals = arrFilters[a].split('::');
							//now lets scroll through all the shows in the guide and
							//compare show's title to values in the array arrFilterVals
							var divChannels=document.getElementsByClassName('listing-entity');
							for(var b=0; b<divChannels.length; b++){
								for(var c=0; c<arrFilterVals.length; c++){
									if(arrFilterVals[c]==divChannels[b].innerHTML){
										//console.log('we have a match!');
										if(!divChannels[b].parentNode.parentNode.classList.contains(this.innerHTML.replace(' ', ''))){
											if(!divChannels[b].parentNode.parentNode.classList.contains('HideMe')){
												divChannels[b].parentNode.parentNode.setAttribute('style', 'display: block;');
											}
											divChannels[b].parentNode.parentNode.classList.remove('no' + this.innerHTML.replace(' ', ''));
											divChannels[b].parentNode.parentNode.className=
												divChannels[b].parentNode.parentNode.className + ' ' + this.innerHTML.replace(' ','');
										}
									}else{
										//this show does not match the filter, but another might, so lets check the parents class
										if(!divChannels[b].parentNode.parentNode.classList.contains(this.innerHTML.replace(' ',''))){
											//console.log('no match');
											divChannels[b].parentNode.parentNode.setAttribute('style', 'display: none;');
											if(!divChannels[b].parentNode.parentNode.classList.contains('no' + this.innerHTML.replace(' ',''))){
												divChannels[b].parentNode.parentNode.className=
													divChannels[b].parentNode.parentNode.className + ' no' + this.innerHTML.replace(' ','');
											}
										}
									}
								}
							}			
						}
					}
				}
			}
			divFilterCategory.appendChild(lnkCustomFilter);
			//arrTerms=[];
		}else{
			//arrTerms.push(arrFilter[x]);
		}
	}
} 


//Create branding link
var lnkBranding = document.createElement('a');
lnkBranding.innerHTML='More From Developer';
lnkBranding.setAttribute('class', 'button filter');
lnkBranding.href=chrome.extension.getURL('appsFromDeveloper/appsFromDeveloper.html');
lnkBranding.target='_blank';
divFilters.appendChild(lnkBranding);


function createHideMe(parent){
	var lnkHideChannel=document.createElement('a');
	lnkHideChannel.innerHTML = 'Hide Me!';
	lnkHideChannel.setAttribute('style', 'display: block; width: 41px; cursor: pointer;');
	lnkHideChannel.setAttribute('class', 'hideChannels');
	//lnkHideChannel.href="#";
	lnkHideChannel.onclick=function(){
		parent.childNodes[3].setAttribute('style', 'background-color: DarkGray; width: 283px');
		parent.className=parent.className + "HideMe";
		parent.className=parent.className.replace(" ShowMe", " ");
		if(!localStorage['xfinityHide']){localStorage['xfinityHide']='';}
		localStorage['xfinityHide']+=parent.id + ";";
	};
	return lnkHideChannel;
}

function createUnHide(parent){
	var lnkUnHide=document.createElement('a');
	//this is an issue, not sure why 
	//probably because of asynchronous as described above
	//lnkUnHide.innerHTML = 'Unhide Me';
	lnkUnHide.setAttribute('style', 'display: block; width: 41px; cursor: pointer;');
	lnkUnHide.setAttribute('class', 'unHideChannels');
	//lnkUnHide.href="#";
	lnkUnHide.onclick=function(){
		if(!localStorage['xfinityHide']){localStorage['xfinityHide']='';}
		localStorage['xfinityHide']=localStorage['xfinityHide'].replace(parent.id + ";", '');
		parent.childNodes[3].setAttribute('style', 'width: 283px;');
		parent.className=parent.className + "ShowMe";
		parent.className=parent.className.replace(" HideMe", " ");
	};
	return lnkUnHide;
}


function hideRows(){
	if(localStorage['xfinityHide']){
		var arr = localStorage['xfinityHide'].split(';');
		var arrLength = arr.length;
		for (var i = 0; i < arrLength; i++) {
			$('#' + arr[i]).hide();
		}
	}
}
