if(!localStorage['xfinityHide']){localStorage['xfinityHide']='';}

//Create the remove favorites button
var lnkRemoveFavs = document.createElement('a');
lnkRemoveFavs.innerHTML = 'Remove All Favorites';
lnkRemoveFavs.setAttribute('class',  'button filter');
var divFilters = document.getElementsByClassName('option-filters')[0];
divFilters.appendChild(lnkRemoveFavs);

lnkRemoveFavs.onclick=function(){
	var style;
	var display = '';
	var lnkFavorites = document.getElementsByClassName('hover-remove');
	
	try{
		for (var i = 0; i < lnkFavorites.length; i++){
			style= window.getComputedStyle(lnkFavorites[i]);
			display=style.getPropertyValue('display');
			if(display=='block'){
				lnkFavorites[i].click();
			}
		}
	}catch(err){
		console.log(err);
	}
}

//create the Hide Channels button
var lnkHide = document.createElement('a');
lnkHide.innerHTML = 'Hide Channels'
lnkHide.setAttribute('class',  'button filter');
divFilters.appendChild(lnkHide);

lnkHide.onclick = function(){
	//I would like to do most of the below code when the page is finished loading
	//but the dom is finished loading before the channels
	//running the below on the button press is a way of making sure all of the 
	//channels are loaded completely.
	var divChannels = document.getElementsByClassName('channels')[0].children;
	if($('.hideChannels').length==0){	
		for(var i=2; i < divChannels.length; i++){
			try{
					var elem=divChannels[i].childNodes[3];
					elem.appendChild(createHideMe(elem.parentNode));
					elem.appendChild(createUnHide(elem.parentNode));
					var x = elem.parentNode.id;
					if(localStorage['xfinityHide'].indexOf(x)>-1){
						elem.setAttribute('style', 'width: 283px; background-color: DarkGray;');
					}else{
						elem.setAttribute('style', 'width: 283px;');
					}
			}catch(err){
				console.log(err);
			}
		}
		$('.hover-add').css('border-left', '0px');
		$('.hover-remove').css('border-left', '0px');
		//This next bit has to be done here
		//I suspect it is because Chrome is asynchronous,
		//so the element does not exist in the DOM by the time
		//createUnHideMe runs
		for(i=0; i < $('.unHideChannels').length; i++){
			$('.unHideChannels')[i].innerHTML='Unhide Me!';
		}
	}
	hideRows();

}

//Create the Show Hidden Channels button
var lnkShowHidden = document.createElement('a');
lnkShowHidden.innerHTML='Show Hidden';
lnkShowHidden.setAttribute('class', 'button filter');
divFilters.appendChild(lnkShowHidden);
lnkShowHidden.onclick=function(){
	$('.channel').show();
}

function createHideMe(parent){
	var lnkHideChannel=document.createElement('a');
	lnkHideChannel.innerHTML = 'Hide Me!';
	lnkHideChannel.setAttribute('style', 'display: block; width: 41px; cursor: pointer;');
	lnkHideChannel.setAttribute('class', 'hideChannels');
	//lnkHideChannel.href="#";
	lnkHideChannel.onclick=function(){
		parent.childNodes[3].setAttribute('style', 'background-color: DarkGray; width: 283px');
		if(!localStorage['xfinityHide']){localStorage['xfinityHide']='';}
		localStorage['xfinityHide']+=parent.id + ";";
	};
	return lnkHideChannel;
}

function createUnHide(parent){
	var lnkUnHide=document.createElement('a');
	//this is an issue, not sure why 
	//probably because of asynchronous as described above
	//lnkUnHide.innerHTML = 'Unhide Me';
	lnkUnHide.setAttribute('style', 'display: block; width: 41px; cursor: pointer;');
	lnkUnHide.setAttribute('class', 'unHideChannels');
	//lnkUnHide.href="#";
	lnkUnHide.onclick=function(){
		if(!localStorage['xfinityHide']){localStorage['xfinityHide']='';}
		localStorage['xfinityHide']=localStorage['xfinityHide'].replace(parent.id + ";", '');
		parent.childNodes[3].setAttribute('style', 'width: 283px;');
	};
	return lnkUnHide;
}


function hideRows(){
	if(localStorage['xfinityHide']){
		var arr = localStorage['xfinityHide'].split(';');
		var arrLength = arr.length;
		for (var i = 0; i < arrLength; i++) {
			$('#' + arr[i]).hide();
		}
	}
}
