var debug = false;

chrome.storage.sync.get(
	'debug', function(result){
		if(result['debug'] == 1) debug = true;
	}
);

if(!localStorage['htvlView']){localStorage['htvlView']='';}

var strHidden = '329;602;028;831;995;095;996;096;999;099;063;881;690;192;112;107;324;037;889;540;498;868;041;989;592;636;114;583;726;058;115;103;029;714;713;715;855;855;922;654;588;732;661;159;645;647;480;146;053;054;570;817;060;122;941;942;615;007;846;644;020;104;105;660;643;113;062;593;880;125;135;641;039;575;869;287;877;046;622;998;098;150;986;701;702;703;704;705;706;851;712;006;005;585;719;730;047;664;291;597;799;106;720;721;722;670;056;820;044;839;231;584;627;032;857;148;009;824;725;567;771;772;773;774;775;776;777;778;779;682;780;781;782;783;784;669;789;790;003;849;651;066;116;157;301;311;491;801;487;488;901;785;490;043;838;875;038;577;579;064;055;717;023;088;808;130;993;111;164;501;167;502;072;543;069;025;184;587;992;027;204;119;802;845;004;021;320;322;233;319;437;413;418;412;422;447;407;448;424;449;427;450;429;417;431;416;433;415;435;414;401;421;439;423;441;425;443;411;445;410;426;409;430;402;434;408;438;403;442;446;432;419;406;420;405;436;428;444;440;404;176;738;327;321;366;151;499;315;812;052;049;605;601;328;863;749;002;848;733;860;246;861;263;734;871;109;739;061;616;330;607;728;155;123;626;549;544;882;662;663;016;806;679;657;637;635;655;110;872;696;341;346;342;340;238;339;987;089;283;347;888;990;988;191;694;736;030;693;128;370;372;375;374;371;369;248;373;571;623;031;829;033;826;297;036;008;751;752;753;754;755;756;757;758;759;620;633;547;735;652;040;837;604;566;760;325;350;351;352;787;787;862;034;825;065;141;991;045;035;680;695;612;618;100;674;621;057;822;564;562;189;010;823;559;870;050;545;594;649;611;011;208;811;015;805;117;051;026;800;561;018;017;019;807;108;013;813;668;012;563;022;014;804;294;689;198;196;024;803;565;981;960;970;186;550;001;548;542;691;850';
chrome.storage.sync.get(
	'strHidden', function(result){
		if(result['strHidden'] === undefined){
			setKey('strHidden', strHidden);
		}
	}
);

//if(!localStorage['htvlHide']){localStorage['htvlHide'] = strHiddenChannels;}

//localStorage['xfinityStatus'] = 'loading';
/* replaced with mutation observer
var actualCode = '(' + function() {
    $(document).ajaxComplete(
		function() {       
			window.postMessage({ type: 'complete', text: $('.channel').length }, '*');
		}
	);
    $(document).ajaxStop(
		function() {       
			window.postMessage({ type: 'stop', text: $('.channel').length }, '*');
		}
	);	
} + ')();';
var script = document.createElement('script');
script.textContent = actualCode;
document.head.appendChild(script);
*/


if(!localStorage['htvlNumOfChannels']) localStorage['htvlNumOfChannels'] = 0;
//create an observer to watch for changes to the dom
//this is how we know when channels are loaded
var target = document.querySelector('.channels');
var observer = new MutationObserver(
	function(mutations) {
		mutations.forEach(
			function(mutation) {
				//$('#channels-filters-empty').remove();
				if(mutation.type === "childList"){
					if(debug)console.log('init ' + $('.channel').length);
					init();
					$('.HideMe').hide();
					if(localStorage['htvlNumOfChannels'] < $('.channel').length){
						localStorage['htvlNumOfChannels'] = $('.channel').length;	
					}else if(localStorage['htvlNumOfChannels'] == $('.channel').length){
						if(debug)console.log('All ' + $('.channel').length + ' channels are loaded');
						if($('.selected[data-filter]').length){
							$('#lnkHideChannels').text('Hide Channels');
						}else{
							switch(localStorage['htvlView']){
								case '':						
									$('#lnkHideChannels').text('Hide Channels');
									$('#lnkHideChannels').click();
									break;
									
								case 'Show Channels':								
									$('#lnkHideChannels').text('Show Channels');
									$('#lnkHideChannels').click();
									break;
									
								case '#lnkHd':
									//this is to correct a bug in the website
									//where gridFilter is ",hd"
									localStorage['gridFilters'] = '"hd"';
									$('#lnkHd').click();
									break;
									
								default:
									$(localStorage['htvlView']).addClass('selected');
									$(localStorage['htvlView']).click();
									break;
							}
						}
						$('#lnkLoading').hide();
						$('#channels-filters-empty').attr('style', 'display: none');
					}
				}
			}
		);    
	}
);
// configuration of the observer:
var config = { attributes: false, childList: true, characterData: false };
observer.observe(target, config);


/*	replaced with mutation observer
var lastCount = 0;
window.addEventListener(
	"message", function(event) {
		
		// We only accept messages from ourselves
		if (event.source != window) return;
		
		
		if (event.data.type && (event.data.type == "complete")) {
			if(event.data.text > lastCount){
				lastCount = event.data.text;
				if(debug) console.log('init ' + lastCount + ' channels');
				//init();
				//hideRows();
			}else{console.log('could not process channels');}
		}
		if (event.data.type && (event.data.type == "stop")) {
			//loading is complete
			if(debug) console.log('ajax stop!  Loaded ' + $('.channel').length + ' channels')
			if(localStorage['xfinityStatus'] == 'loading'){
				localStorage['xfinityStatus'] = 'complete';
				if($('.selected[data-filter]').length){
					$('#lnkHideChannels').text('Hide Channels');
				}else{
					switch(localStorage['xfinityView']){
						case '':
							$('#lnkHideChannels').addClass('selected');
							break;
						case 'Show Channels':
							$('#lnkHideChannels').addClass('selected');
							$('#lnkHideChannels').text('Hide Channels');
							$('.channel').show();
							break;
						default:
							$(localStorage['xfinityView']).addClass('selected');
							$(localStorage['xfinityView']).click();
							break;
					}
				}
				$('#lnkLoading').hide();
			}
		}		
	}, false
);
*/



$(document).ready(function(){
	checkLastWatchedDate();
	watchChannelListener();
	
	$('.button.filter.hd').attr('id', 'lnkHd');
	$('.button.filter.movies').attr('id', 'lnkMovies');
	$('.button.filter.sports').attr('id', 'lnkSports');
	$('.button.filter.kids').attr('id', 'lnkKids');
	$('#channels-filters-empty').attr('style', 'display: none');
	
	//options
	var wrapper = document.getElementsByClassName('change-location-wrapper')[0];
	var lnk = document.createElement('a');
	lnk.id = 'lnkOptions';
	lnk.innerHTML = 'htvl Options';
	lnk.className = 'print-button';
	lnk.setAttribute('style', 'cursor: pointer;');
	lnk.href = chrome.extension.getURL('htvlOptions.html');
	lnk.target = '_blank';
	wrapper.appendChild(lnk);

	
	if(!localStorage['htvlInstalled']){
		localStorage['htvlInstalled'] = 'installed';
		alert('htvl has been installed or updated!\n' + 
			  'Notice the options button on the right.\n' + 
			  'Use it to configure the guide\n\n' +
			  'Once all the channels are loaded, please refresh the page to complete the install.'
			  );
		//see if this is an existing user and attempt to import their settings
		if(localStorage['xfinityFilters'] && localStorage['xfinityFilterUpdates'] == 'False'){
			try{
				//these strings will have a trailing ; this removes it
				if(localStorage['xfinityHide'])localStorage['xfinityHide'] = localStorage['xfinityHide'].slice(0, -1);
				if(localStorage['xfinityFilters']) localStorage['xfinityFilters'] = localStorage['xfinityFilters'].slice(0, -1);
				if(localStorage['xfinityHide']) setKey('strHidden', localStorage['xfinityHide']);
				var arr = localStorage['xfinityFilters'].split(';').reverse();
				var strTerms = '';
				for(var i = 0; i <= arr.length - 1; ++i){
					strTerms = '';

					var arr2 = arr[i].split('::');
					console.log('b' + i + 'title = ' + arr2[0]);
					setKey('b' + i + 'title', arr2[0]);
					setKey('b' + i, '1');
					for(var x = arr2.length - 1; x >= 0; --x){
						//avoid title
						if(x != 0) strTerms +=  arr2[x] + ';';
					}
					strTerms = strTerms.slice(0, - 1); //remove trailing ;
					setKey('b' + i + 'terms', strTerms);
				}
			}catch(err){
				alert('htvl attempted to import your custom filters, but there was an error.\n' + 
					  'You will have to enter them manually.');
				console.log(err);
			}
		}		
			  
			  
	}
	setDefaults();
		
	//create loading icon
	lnk = document.createElement('a');
	lnk.id = 'lnkLoading';
	var strLoading = localStorage['htvlView'];
	var $selectedFilter = $('.selected[data-filter]');
	if($selectedFilter.length){
		strLoading = $selectedFilter.text();
	}
	lnk.innerHTML = 'Please Wait...loading ' + localStorage['htvlView'].replace('#lnk', '');
	lnk.className = 'print-button';
	wrapper.appendChild(lnk);
	
	//removes a break in the menu
	var divContainer = document.getElementsByClassName('option-filters')[0];

	$('.button.filter.hd').next().remove();
	
	//hide channels
	lnk = document.createElement('a');
	lnk.id='lnkHideChannels';
	lnk.setAttribute('class',  'button filter');
	if(localStorage['htvlView'] == 'Show Channels'){
		lnk.innerHTML = 'Hide Channels'
		lnk.setAttribute('style', 'background:-webkit-linear-gradient(top,#400101 0,#EB1A1A 100%)');
	}else{
		lnk.innerHTML = 'Show Hidden';
	}
	divContainer.appendChild(lnk);
	lnk.onclick = function(){
		observer.disconnect();
		sortChannels();
		clearFilters();
		window.scrollTo(0, 0);
		$('.selected').removeClass('selected');
		$('#lnkHideChannels').addClass('selected');
		showHidden();
		if($('#lnkHideChannels').text() == 'Hide Channels'){
			var channels = document.getElementsByClassName('channel');
			var channel;
			var hoverWatch;
			
			chrome.storage.sync.get(
				'strHidden', function (items) {
					for(var i = channels.length - 1; i >= 0; --i){
						channel = channels[i];
						hoverWatch = channel.childNodes[3];
						if(items['strHidden'].toString().indexOf(channel.id) > -1){
							hoverWatch.setAttribute('style', 'width: 283px; background-color: DarkGray;');
							channel.classList.remove('ShowMe');
							channel.classList.remove('HideMe');
							channel.className = channel.className + " HideMe";
						}else{
							hoverWatch.setAttribute('style', 'width: 283px;');
							channel.classList.remove('ShowMe');
							channel.classList.remove('HideMe');
							channel.className = channel.className + " ShowMe";
						}
					}
					hideRows();	
				}
			);

			$('#lnkHideChannels').text('Show Hidden');
			$('#lnkHideChannels').attr('style', 'background:-webkit-linear-gradient(top,#006fa8 0,#0094cd 100%))');
			localStorage['htvlView'] = '';
		}else{
			$('#lnkHideChannels').text('Hide Channels');
			localStorage['htvlView'] = 'Show Channels';
			$('#lnkHideChannels').attr('style', 'background:-webkit-linear-gradient(top,#400101 0,#EB1A1A 100%)');
			$('.channel').show();
		}
		observer.observe(target, config);
	}
		
	//Create branding link
	divSearch = document.getElementsByClassName('options')[0];
	var br = document.createElement('br');
	divSearch.appendChild(br);
	
	lnk = document.createElement('a');
	lnk.innerHTML = 'More From Developer';
	lnk.setAttribute('class', 'button filter');
	lnk.href = chrome.extension.getURL('appsFromDeveloper/appsFromDeveloper.html');
	lnk.target = '_blank';
	divSearch.appendChild(lnk);

	lnk = document.createElement('a');
	lnk.innerHTML = 'printSync';
	lnk.id = 'lnkPrintSync';
	lnk.setAttribute('class', 'button filter');
	if(debug) divContainer.appendChild(lnk);
	lnk.onclick = function(){
		printSync('a');
	}
	
	lnk = document.createElement('a');
	lnk.innerHTML = 'clearSync';
	lnk.id = 'lnkClearSync';
	lnk.setAttribute('class', 'button filter');
	if(debug) divContainer.appendChild(lnk);
	lnk.onclick = function(){
		chrome.storage.sync.clear();
		localStorage['htvlNumOfChannels'] = 0;
	}

	createButtons();

	if(debug) console.log('end document ready');
});



//////////////////ADD BUTTONS TO THE MENU//////////////////////////////
function createButtons(){
	chrome.storage.sync.get(
		null, function (result) {
			var divContainer = document.getElementsByClassName('option-filters')[0];
			var div = document.getElementsByClassName('option-filters')[1];
			for(var key in result){
				switch(key){
					case 'lnkRemoveAllFavorites':
						createLnkRemoveAllFavorites(divContainer, result[key]);
						break;
					// case 'lnkHd':
						// if(result[key] == 0) $('#lnkHd').hide();
						// break;
					case 'lnkHd':
						createLnkHd(divContainer, result[key]);
						break;
					case 'lnkFavorites':
						createLnkFavorites(divContainer, result[key]);
						break;
					case 'lnkLast':
						createLnkLast(divContainer, result[key]);
						break;
					case 'lnkRecording':
						createLnkRecording(divContainer, result[key]);
						break;
					case 'lnkMostWatched':
						createLnkMostWatched(divContainer, result[key]);
						break;
					case 'lnkMovies':
						if(result[key] == 0) $('#lnkMovies').hide();
						break;
					case 'lnkSports':
						if(result[key] == 0) $('#lnkSports').hide();
						break;	
					case 'lnkKids':
						if(result[key] == 0) $('#lnkKids').hide();
						break;
					default:
				}
			}
			for(var i = 0; i < 10; i++){
				createLnkSports(div, result['b' + i],  result['b' + i + 'title'], result['b' + i + 'terms'], 'b' + i);
			}
			setSortOrder();
			$('[sortorder]').tsort({attr:'sortorder'});
		}
	);
}

function createLnkSports(div, btn, title, terms, b){
	if(btn == 0) return;
	if(title === undefined) return;
	if(terms === undefined) return;
	
	lnk = document.createElement('a');
	lnk.innerHTML = title;
	lnk.setAttribute('class', 'button filter');
	lnk.id = b;
	div.appendChild(lnk);	
	lnk.onclick = function(){
		observer.disconnect();		
		clearFilters();
		sortChannels();
		$('.selected').removeClass('selected');
		$(this).addClass('selected');
		$('#lnkHideChannels').text('Hide Channels');
		$('#lnkHideChannels').css('background', '');
		$('.channel').hide();
		$('#lnkLoading').text('Please Wait...loading ' + title);
		$('#lnkLoading').show();
		window.scrollTo(0, 0);
		chrome.storage.sync.get(
			b + 'terms', function (result) {
				var arr = result[b + 'terms'].split(';');
				if(arr[arr.length - 1] == '') arr.pop();
				for(var i = arr.length - 1; i >= 0; --i){
					$('*:contains(' + arr[i] + ')').each(
						function(x){
							if($(this).text() == arr[i]){
								$(this).parent().parent().addClass(title.replace(' ', ''));
							}
						}
					);
				}						
				$('.ShowMe.' + title.replace(' ', '')).show();
				$('#lnkLoading').hide();
				observer.observe(target, config);
			}
		);
		localStorage['htvlView'] = '#' + b;
		$('#channels-filters-empty').attr('style', 'display: none');
	}
}

function createLnkMostWatched(divContainer, value){
	//most watched
	if(value == 0) return;
	lnk = document.createElement('a');
	lnk.innerHTML='Most Watched';
	lnk.id = 'lnkMostWatched';
	lnk.setAttribute('class', 'button filter');
	divContainer.appendChild(lnk);
	lnk.onclick = function(){
		observer.disconnect();	
		clearFilters();
		$('#lnkMostWatched').addClass('selected');
		$('.channel').hide();
		localStorage['htvlView'] = '#lnkMostWatched';
		$('#lnkHideChannels').text('Hide Channels');
		$('#lnkHideChannels').css('background', '');
		localStorage['htvlUnsorted'] = 'unsorted';
		window.scrollTo(0, 0);
		
		chrome.storage.sync.get(
			'mostWatched', function (items) {
				if(items['mostWatched'] === undefined) return;
				
				var arr = items['mostWatched'].toString().split(';');
				var arr2;
				$('*').removeAttr('mostwatched');
				for(var i = arr.length - 1; i >= 0; --i){
					arr2 = arr[i].split('=');
					$('#' + arr2[0]).attr('mostwatched', arr2[1]);
				}
				$('[mostwatched]').tsort({order:'desc',attr:'mostwatched'});
				$('[mostwatched]').show();
				observer.observe(target, config);
			}
		);	
	}
}

function createLnkRecording(divContainer, value){
	//Recording
	if(value == 0) return;
	lnk = document.createElement('a');
	lnk.innerHTML = 'Recording';
	lnk.id = 'lnkRecording';
	lnk.setAttribute('class', 'button filter');
	divContainer.appendChild(lnk);
	lnk.onclick = function(){
		observer.disconnect();
		sortChannels();
		clearFilters();
		$('#lnkHideChannels').text('Hide Channels');
		$('#lnkHideChannels').css('background', '');
		$(this).addClass('selected');
		$('.channel').hide();
		
		chrome.storage.sync.get(
			'recording', function (result) {
				if(result['recording'] === undefined) return;
				var arr = result['recording'].split(';');
				$('.badge.new, .badge.live').siblings('.listing-entity').addClass('htvlNew');
				for(var i = arr.length - 1; i >= 0; --i){
					$('*:contains(' + arr[i] + ')').addClass('rec');
				}
				$('.rec.htvlNew').parent().parent('.ShowMe').show();
				localStorage['htvlView'] = '#lnkRecording';	
				window.scrollTo(0, 0);
				observer.observe(target, config);
			}
		);
	}
}

function createLnkLast(divContainer, value){
	//last
	if(value == 0) return;
	lnk = document.createElement('a');
	lnk.innerHTML = 'Last';
	lnk.id = 'lnkLast';
	lnk.setAttribute('class', 'button filter');
	divContainer.appendChild(lnk);
	lnk.onclick = function(){
		observer.disconnect();
		clearFilters();
		$('#lnkHideChannels').css('background', '');
		$('#lnkLast').addClass('selected');
		$('#lnkHideChannels').text('Hide Channels');
		//populate last watched class
		$('.watchedLast').removeClass('watchedLast');	
		localStorage['htvlView'] = '#lnkLast';
		window.scrollTo(0, 0);
		
		chrome.storage.sync.get(
			null, function (items) {
				var channel;
				$('.channel').hide();
				if(items['last'] === undefined) return;
				var arr = items['last'].split(';');
				arr.pop();
				for(var i = arr.length - 1; i >= 0; --i){
					$('#' + arr[i]).addClass('watchedLast');
					channel = $('#' + arr[i])[0]
					channel.setAttribute('watchedLast', i);
				}
				
				$('.watchedLast').show();
				localStorage['htvlUnsorted'] = 'unsorted';
				$('.watchedLast').tsort({order:'desc',attr:'watchedLast'});
				observer.observe(target, config);
			}
		);
	}
}

function createLnkRemoveAllFavorites(divContainer, value){
	//remove favorites
	if(value == 0) return;
	lnk = document.createElement('a');
	lnk.innerHTML = 'Remove All Favorites';
	lnk.id = 'lnkRemoveAllFavorites';
	lnk.setAttribute('class',  'button filter');
	divContainer.appendChild(lnk);
	lnk.onclick = function(){
		var style;
		var display = '';
		var hoverRemove = document.getElementsByClassName('hover-remove');
		for (var i = hoverRemove.length - 1; i >= 0; --i){
			style = window.getComputedStyle(hoverRemove[i]);
			display = style.getPropertyValue('display');
			if(display == 'block'){
				hoverRemove[i].click();
			}
		}
		window.scrollTo(0, 0);
	}
}

function createLnkFavorites(divContainer, value){
	//duplicate the favorites button
	//to avoid the annoying message box when there are no favorites
	$('.button.filter.favorites').remove();
	if(value == 0) return;
	lnk = document.createElement('a');
	lnk.innerHTML = 'Favorites';
	lnk.id = 'lnkFavorites';
	lnk.setAttribute('class', 'button filter favorites');
	divContainer.appendChild(lnk);
	var b = document.createElement('b');
	lnk.appendChild(b);
	lnk.onclick = function(){
		observer.disconnect();	
		clearFilters();
		sortChannels();
		$('.channel').hide();
		$('.ShowMe.fav').show();
		$('#lnkHideChannels').text('Hide Channels');
		$('#lnkHideChannels').css('background', '');
		$(this).addClass('selected');
		localStorage['htvlView'] = '#lnkFavorites';
		window.scrollTo(0, 0);
		observer.observe(target, config);		
	}
}

function createLnkHd(divContainer, value){
	//duplicate the hd button
	//to avoid a bug with the default hd button
	$('.button.filter.hd').remove();
	if(value == 0) return;
	lnk = document.createElement('a');
	lnk.innerHTML = 'HD Only';
	lnk.id = 'lnkHd';
	lnk.setAttribute('class', 'button filter hd');
	divContainer.appendChild(lnk);
	var span = document.createElement('span');
	span.setAttribute('class', 'font-icon-hd');
	lnk.appendChild(span);
	lnk.onclick = function(){
		observer.disconnect();	
		clearFilters();
		sortChannels();
		$('.channel').hide();
		$('.channel.hd.ShowMe').show();
		$('#lnkHideChannels').text('Hide Channels');
		$('#lnkHideChannels').css('background', '');
		$(this).addClass('selected');
		localStorage['htvlView'] = '#lnkHd';
		window.scrollTo(0, 0);
		localStorage['gridFilters'] = '';
		observer.observe(target, config);		
	}
}




