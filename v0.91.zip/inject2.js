
function printSync(detail){
//for debugging only
//just prints the sync values to the console
//printSync();
//printSync('true');
	if(typeof detail === 'undefined'){
		chrome.storage.sync.get(null, function (data) { console.info(data) });
	}else{
		chrome.storage.sync.get(
			null, function (items) {
				for(var key in items){
					console.log(key + ' ' + items[key]);
				}
			}
		);
	}
}