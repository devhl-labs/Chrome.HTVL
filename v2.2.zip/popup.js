var newURL = "https://tv.xfinity.com/listings";
chrome.tabs.create({ url: newURL });
