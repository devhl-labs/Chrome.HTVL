//this version is published to testers only, no longer used
chrome.management.setEnabled('hkmkpjagnahjgfdkjolfdnlanmamifof', false);

//previous version that is no longer published, no longer used
chrome.management.setEnabled('gnbeokkohplojcckboakfdippdeclilo', false);

//offline dev version
chrome.management.setEnabled('kdojmcccbhhadlknkjnomcpmkbhlfhbm', false);

//published to testers only
//offline dev version
chrome.management.setEnabled('jnfpmhniiknmcclcdjfhbeboahhkgkhm', false);

//online published version
chrome.management.setEnabled('emahdgfobodhknccbigjmnhpgihmmjbf', true);









