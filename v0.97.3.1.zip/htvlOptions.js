//create key if it does not exist
var keys = [
	'lnkHd', 
	'lnkFavorites',
	'lnkRemoveAllFavorites',
	'lnkHideChannels',
	'lnkLast',
	'lnkRecording',
	'lnkMostWatched',
	'lnkMovies',
	'lnkSports',
	'lnkKids',
	
	'recording',
	'debug',
	'strHidden'
];

for(var i = 0; i < 10; ++i){
	keys.push('b' + i);
	keys.push('b' + i + 'title');
	keys.push('b' + i + 'terms');
}

chrome.storage.sync.get(
	keys, function(result){
		keys.forEach(
			function(key){
				if(key == 'debug'){
					if(result['debug'] === undefined){
						setKey('debug', '0');
					}else if(result['debug'] == '1'){
						$('#debug').prop('checked', true)
					}
				}
				if((result[key] == 1 || result[key] === undefined) && key.length != 2 && key != 'debug') $('#' + key).attr('checked', 'checked');
				if(result[key] == 1 && key.length == 2) $('#' + key).attr('checked', 'checked');
				if(key == 'recording' && result[key] !== undefined){
					var arr = result[key].split(';');
					for(var i = 0; i <= arr.length - 1; ++i){
						addRecordingRow(arr[i]);
					}
				}
				if(key == 'recording'){
					addRecordingRow();
					addRecordingRow();
					addRecordingRow();
				}
				
				if(key == 'strHidden'){
					//console.log(result[key]);
					var arrHidden = [];
					arrHidden = result[key].split(';').sort().reverse();
					for(var i = arrHidden.length - 1; i > 0; --i){
						//console.log(arrHidden[i]);
						$('#hiddenChannels').append(arrHidden[i] + '<br />');
					}
				}
					
				for(var x = 0; x < 10; ++x){
					if(key == ('b' + x + 'title')){
						$('#b' + x + 'title').val(result[key]);
					}
					if(key =='b' + x + 'terms' && result[key] !== undefined){
						arr = result[key].split(';');
						for(i = 0; i <= arr.length - 1; ++i){
							addSearchTerm($('#tblb' + x), x, arr[i]);
						}
					}
					if(key == 'b' + x + 'terms'){
						addSearchTerm($('#tblb' + x), x);
						addSearchTerm($('#tblb' + x), x);
						addSearchTerm($('#tblb' + x), x);							
					}
				}
			}
		)
	}
);

function addSearchTerm($tbl, x, value){
	var tr = document.createElement('tr');
	var td = document.createElement('td');
	var input = document.createElement('input');
	var text = document.createTextNode('term');
	input.setAttribute('type', 'text');
	input.className = 'b' + x + 'term';
	$tbl.append(tr);
	tr.appendChild(td);
	td.appendChild(text);
	td = document.createElement('td');
	tr.appendChild(td);
	td.appendChild(input);
	if(value !== undefined) input.value = value;
	input.onchange = function(){
		var str = '';
		var len = $('.b' + x + 'term').length;
		$('.b' + x + 'term').each(
			function(i){
				if($(this).val()) str += $(this).val() + ';';
			}
		);
		str = str.slice(0, -1); 
		setKey('b' + x + 'terms', str);
	}
}

function addRecordingRow(value){
	var $table = $('#tblRecording');
	var tr = document.createElement('tr');
	
	$table.append(tr);
	var td = document.createElement('td');
	tr.appendChild(td);
	var input = document.createElement('input');
	input.className = 'recording';
	if(typeof value === 'string')input.value = value;
	td.appendChild(input);
	var str = '';
	input.onchange = function (){
		str = '';
		$('.recording').each(
			function(i){
				if($(this).val().length > 0) str += $(this).val() + ';';
			}
		);
		str = str.slice(0, -1);
		setKey('recording', str);
	}

}

function hideMenus(){
	$('#controls').hide();
	$('#recordings').hide();
	$('#customFilters').hide();
	$('#otherOptions').hide();
	$('#help').hide();
	$('#hidden').hide();
}

$(init);
function init(){
	$('#lnkEnableButtons').click();
	for(var i = 0; i <=9; i++){
		changeTitle(i);
	}

	
}

function changeTitle(i){
	chrome.storage.sync.get(
		'b' + i + 'title', function(result){
			if(result['b' + i + 'title'] !== undefined){
				$('option[value=' + i + ']').text(result['b' + i + 'title']);
			}
		}
	)
}

function setKey(key, value){
	var obj = {};
	obj[key] = value;
	chrome.storage.sync.set(obj);
}

function printSync(detail){
//for debugging only
//just prints the sync values to the console
//printSync();
//printSync('true');
	if(typeof detail === 'undefined'){
		chrome.storage.sync.get(null, function (data) { console.info(data) });
	}else{
		chrome.storage.sync.get(
			null, function (items) {
				for(var key in items){
					console.log(key + ' ' + items[key]);
				}
			}
		);
	}
}






////////////////Bindings////////////////////////////////
$('.title').bind(
	'change', function(){
		setKey($(this).attr('id'), $(this).val());
	}
);

$('.toggle').bind(
	'change', function() {
		var value = 0;
		if($(this).attr('checked') == 'checked'){
			value = 1;
		}else{
			value = 0;
		}
		
		setKey(this.id, value);
	}
);


$('#lnkBranding').bind(
	'click', function(){
		window.location = chrome.extension.getURL('appsFromDeveloper/appsFromDeveloper.html');
	}
);

$('#lnkCustomFilters').bind(
	'click', function() {
		$('*').removeClass('selected');
		$(this).addClass('selected');
		hideMenus();
		$('#customFilters').show();
		$('#customFilters *').show();
		$('#filterFields * ').hide();
		$('#0, #0 *').show();
	}
);

$('SELECT').on('change',function(){
	$('#filterFields * ').hide();
	$('#' + $(this).attr('value') + ', ' + '#' + $(this).attr('value') + ' *').show();
});


$('#lnkEnableButtons').bind(
	'click', function() {
		$('*').removeClass('selected');
		$(this).addClass('selected');
		hideMenus();
		$('#controls').show();
		$('#controls *').show();
	}
);

$('#lnkHidden').bind(
	'click', function(){
		$('*').removeClass('selected');
		$(this).addClass('selected');
		hideMenus();
		$('#hidden').show();
		$('#hidden *').show();
	}
);

$('#lnkOtherOptions').bind(
	'click', function(){
		$('*').removeClass('selected');
		$(this).addClass('selected');
		hideMenus();
		$('#otherOptions').show();
		$('#otherOptions *').show();
	}
);

$('#clearSync').click(
	function(){
		chrome.storage.sync.clear();
		console.log('cleared');
	}
);

$('#printSync').click(
	function(){
		printSync('a');
	}
);

$('#lnkRecordings').bind(
	'click', function() {
		$('*').removeClass('selected');
		$(this).addClass('selected');
		hideMenus();
		$('#recordings').show();
		$('#recordings *').show();
	}
);

$('#lnkHelp').bind(
	'click', function() {
		$('*').removeClass('selected');
		$(this).addClass('selected');
		hideMenus();
		$('#help').show();
		$('#help *').show();
	}
);



