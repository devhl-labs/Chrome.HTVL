
var $filters = $('[data-filter]');
$filters.bind(
	"click", function(){
		$('.selected').removeClass('selected');
		$(this).addClass('selected');
		$('#lnkHideChannels').text('Hide Channels');
		$('#lnkHideChannels').css('background', '');
		$('.channel').hide();
		var filter = $(this).attr('data-filter');
		$('.' + filter).show();
		$('.HideMe').hide();
		$('#channels-filters-empty').hide();
		$('.channels').css({'min-height': '1000px'});
	}
);

$('.button.filter.hd').bind(
	"click", function(){
		localStorage['xfinityView'] = '#lnkHd';
		//$('#lnkHideChannels').css('background', '');
	}
);
$('.button.filter.movies').bind(
	"click", function(){
		localStorage['xfinityView'] = '#lnkMovies';
	}
);
$('.button.filter.sports').bind(
	"click", function(){
		localStorage['xfinityView'] = '#lnkSports';
	}
);
$('.button.filter.kids').bind(
	"click", function(){
		localStorage['xfinityView'] = '#lnkKids';
	}
);




