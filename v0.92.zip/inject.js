var debug = false;

chrome.storage.sync.get(
	'debug', function(result){
		if(result['debug'] == 1) debug = true;
		//debug = result['debug'];
	}
);

setDefaults();

if(!localStorage['xfinityView']){localStorage['xfinityView']='';}
localStorage['gridFilters'] = '""';
localStorage['xfinityStatus'] = 'loading';

var actualCode = '(' + function() {
    $(document).ajaxComplete(
		function() {       
			window.postMessage({ type: 'complete', text: $('.channel').length }, '*');
		}
	);
    $(document).ajaxStop(
		function() {       
			window.postMessage({ type: 'stop', text: $('.channel').length }, '*');
		}
	);	
} + ')();';
var script = document.createElement('script');
script.textContent = actualCode;
document.head.appendChild(script);

localStorage['init'] = 'init'
// select the target node
var target = document.querySelector('.channels');
// create an observer instance
var observer = new MutationObserver(function(mutations) {
  mutations.forEach(function(mutation) {
    if(mutation.type === "childList" && localStorage['init'] == 'init'){
		console.log('mutated');
		init();
	}
  });    
});
 
// configuration of the observer:
var config = { attributes: true, childList: true, characterData: true };
 
// pass in the target node, as well as the observer options
//observer.observe(target, config);



var lastCount = 0;
window.addEventListener(
	"message", function(event) {
		// We only accept messages from ourselves
		if (event.source != window) return;
		if (event.data.type && (event.data.type == "complete")) {
			if(localStorage['xfinityStatus'] == 'reload'){
				lastCount = 0;
				localStorage['xfinityStatus'] = 'loading';
			}
			if(event.data.text > lastCount){
				lastCount = event.data.text;
				if(debug) console.log('init ' + lastCount + ' channels');
				init();
				hideRows();
				observer.observe(target, config);
			}else{console.log('could not process channels');}
		}
		if (event.data.type && (event.data.type == "stop")) {
			//loading is complete
			if(debug) console.log('ajax stop!  Loaded ' + $('.channel').length + ' channels')
			if(localStorage['xfinityStatus'] == 'loading'){
				localStorage['xfinityStatus'] = 'complete';
				if($('.selected[data-filter]').length){
					$('#lnkHideChannels').text('Hide Channels');
				}else{
					switch(localStorage['xfinityView']){
						case '':
							$('#lnkHideChannels').addClass('selected');
							break;
						case 'Show Channels':
							$('#lnkHideChannels').addClass('selected');
							$('#lnkHideChannels').text('Hide Channels');
							$('.channel').show();
							break;
						default:
							$(localStorage['xfinityView']).addClass('selected');
							$(localStorage['xfinityView']).click();
							break;
					}
				}
				$('#lnkLoading').hide();
			}
		}		
	}, false
);



$(document).ready(function(){
	checkLastWatchedDate();
	watchChannelListener();
	
	$('.button.filter.hd').attr('id', 'lnkHd');
	$('.button.filter.movies').attr('id', 'lnkMovies');
	$('.button.filter.sports').attr('id', 'lnkSports');
	$('.button.filter.kids').attr('id', 'lnkKids');
	$('#channels-filters-empty').attr('style', 'display: none');
	
	//options
	var wrapper = document.getElementsByClassName('change-location-wrapper')[0];
	var lnk = document.createElement('a');
	lnk.id = 'lnkOptions';
	lnk.innerHTML = 'htvl Options';
	lnk.className = 'print-button';
	lnk.setAttribute('style', 'cursor: pointer;');
	lnk.href = chrome.extension.getURL('htvlOptions.html');
	lnk.target = '_blank';
	wrapper.appendChild(lnk);
		
	//create loading icon
	lnk = document.createElement('a');
	lnk.id = 'lnkLoading';
	var strLoading = localStorage['xfinityView'];
	var $selectedFilter = $('.selected[data-filter]');
	if($selectedFilter.length){
		strLoading = $selectedFilter.text();
	}
	lnk.innerHTML = 'Please Wait...loading ' + localStorage['xfinityView'].replace('#lnk', '');
	lnk.className = 'print-button';
	wrapper.appendChild(lnk);
	
	//removes a break in the menu
	var divContainer = document.getElementsByClassName('option-filters')[0];
	$('.button.filter.hd').next().remove();
	
	//hide channels
	lnk = document.createElement('a');
	lnk.id='lnkHideChannels';
	lnk.setAttribute('class',  'button filter');
	//lnk.setAttribute('sortorder', '0');
	if(localStorage['xfinityView'] == 'Show Channels'){
		lnk.innerHTML = 'Hide Channels'
		lnk.setAttribute('style', 'background:-webkit-linear-gradient(top,#400101 0,#EB1A1A 100%)');
	}else{
		lnk.innerHTML = 'Show Hidden';
	}
	divContainer.appendChild(lnk);
	lnk.onclick = function(){
		observer.disconnect();
		sortChannels();
		clearFilters();
		window.scrollTo(0, 0);
		$('.selected').removeClass('selected');
		$('#lnkHideChannels').addClass('selected');
		showHidden();
		if($('#lnkHideChannels').text() == 'Hide Channels'){
			var channels = document.getElementsByClassName('channel');
			var channel;
			var hoverWatch;
			
			chrome.storage.sync.get(
				'strHidden', function (items) {
					for(var i = channels.length -1; i >= 0; --i){
						channel = channels[i];
						hoverWatch = channel.childNodes[3];
						if(items['strHidden'].toString().indexOf(channel.id) > -1){
							hoverWatch.setAttribute('style', 'width: 283px; background-color: DarkGray;');
							channel.classList.remove('ShowMe');
							channel.classList.remove('HideMe');
							channel.className = channel.className + " HideMe";
						}else{
							hoverWatch.setAttribute('style', 'width: 283px;');
							channel.classList.remove('ShowMe');
							channel.classList.remove('HideMe');
							channel.className = channel.className + " ShowMe";
						}
					}
					hideRows();	
				}
			);

			$('#lnkHideChannels').text('Show Hidden');
			$('#lnkHideChannels').attr('style', 'background:-webkit-linear-gradient(top,#006fa8 0,#0094cd 100%))');
			localStorage['xfinityView'] = '';
		}else{
			$('#lnkHideChannels').text('Hide Channels');
			localStorage['xfinityView'] = 'Show Channels';
			$('#lnkHideChannels').attr('style', 'background:-webkit-linear-gradient(top,#400101 0,#EB1A1A 100%)');
		}
		observer.observe(target, config);
	}
		
	//Create branding link
	divSearch = document.getElementsByClassName('options')[0];
	var br = document.createElement('br');
	divSearch.appendChild(br);
	
	lnk = document.createElement('a');
	lnk.innerHTML = 'More From Developer';
	lnk.setAttribute('class', 'button filter');
	lnk.href = chrome.extension.getURL('appsFromDeveloper/appsFromDeveloper.html');
	lnk.target = '_blank';
	divSearch.appendChild(lnk);

	lnk = document.createElement('a');
	lnk.innerHTML = 'printSync';
	lnk.id = 'lnkPrintSync';
	lnk.setAttribute('class', 'button filter');
	if(debug) divContainer.appendChild(lnk);
	lnk.onclick = function(){
		printSync('a');
	}
	
	lnk = document.createElement('a');
	lnk.innerHTML = 'clearSync';
	lnk.id = 'lnkClearSync';
	lnk.setAttribute('class', 'button filter');
	if(debug) divContainer.appendChild(lnk);
	lnk.onclick = function(){
		chrome.storage.sync.clear();
	}

	createButtons();

	if(debug) console.log('end document ready');
});



//////////////////ADD BUTTONS TO THE MENU//////////////////////////////
function createButtons(){
	chrome.storage.sync.get(
		null, function (result) {
			var divContainer = document.getElementsByClassName('option-filters')[0];
			var div = document.getElementsByClassName('option-filters')[1];
			for(var key in result){
				switch(key){
					case 'lnkRemoveAllFavorites':
						createLnkRemoveAllFavorites(divContainer, result[key]);
						break;
					case 'lnkHd':
						if(result[key] == 0) $('#lnkHd').hide();
						break;
					case 'lnkFavorites':
						createLnkFavorites(divContainer, result[key]);
						break;
					case 'lnkLast':
						createLnkLast(divContainer, result[key]);
						break;
					case 'lnkRecording':
						createLnkRecording(divContainer, result[key]);
						break;
					case 'lnkMostWatched':
						createLnkMostWatched(divContainer, result[key]);
						break;
					case 'lnkMovies':
						if(result[key] == 0) $('#lnkMovies').hide();
						break;
					case 'lnkSports':
						if(result[key] == 0) $('#lnkSports').hide();
						break;	
					case 'lnkKids':
						if(result[key] == 0) $('#lnkKids').hide();
						break;
					default:
						//console.log(key + '  ' + result[key]);
				}
			}
			for(var i = 0; i < 10; i++){
				createLnkSports(div, result['b' + i],  result['b' + i + 'title'], result['b' + i + 'terms'], 'b' + i);
			}
			setSortOrder();
			$('[sortorder]').tsort({attr:'sortorder'});
		}
	);
}

function createLnkSports(div, btn, title, terms, b){
	if(btn == 0) return;
	if(title === undefined) return;
	if(terms === undefined) return;
	
	lnk = document.createElement('a');
	lnk.innerHTML = title;
	lnk.setAttribute('class', 'button filter');
	lnk.id = b;
	div.appendChild(lnk);	
	lnk.onclick = function(){
		observer.disconnect();	
		clearFilters();
		sortChannels();
		$('.selected').removeClass('selected');
		$(this).addClass('selected');
		$('#lnkHideChannels').text('Hide Channels');
		$('#lnkHideChannels').css('background', '');
		$('.channel').hide();
		$('#lnkLoading').text('Please Wait...loading ' + title);
		$('#lnkLoading').show();
		window.scrollTo(0, 0);
		chrome.storage.sync.get(
			b + 'terms', function (result) {
				var arr = result[b + 'terms'].split(';');
				for(var i = arr.length - 2; i >= 0; --i){
					$('*:contains(' + arr[i] + ')').each(
						function(x){
							if($(this).text() == arr[i]){
								$(this).parent().parent().addClass(title.replace(' ', ''));
							}
						}
					);
				}						
				$('.ShowMe.' + title.replace(' ', '')).show();
				$('#lnkLoading').hide();
			}
		);
		localStorage['xfinityView'] = '#' + b;
		observer.observe(target, config);
	}
}

function createLnkMostWatched(divContainer, value){
	//most watched
	if(value == 0) return;
	lnk = document.createElement('a');
	lnk.innerHTML='Most Watched';
	lnk.id = 'lnkMostWatched';
	lnk.setAttribute('class', 'button filter');
	divContainer.appendChild(lnk);
	lnk.onclick = function(){
		observer.disconnect();	
		clearFilters();
		$('#lnkMostWatched').addClass('selected');
		$('.channel').hide();
		localStorage['xfinityView'] = '#lnkMostWatched';
		$('#lnkHideChannels').text('Hide Channels');
		$('#lnkHideChannels').css('background', '');
		localStorage['unsorted'] = 'unsorted';
		window.scrollTo(0, 0);
		
		chrome.storage.sync.get(
			'mostWatched', function (items) {
				if(items['mostWatched'] === undefined) return;
				
				var arr = items['mostWatched'].toString().split(';');
				var arr2;
				$('*').removeAttr('mostwatched');
				for(var i = arr.length - 1; i >= 0; --i){
					arr2 = arr[i].split('=');
					$('#' + arr2[0]).attr('mostwatched', arr2[1]);
				}
				$('[mostwatched]').tsort({order:'desc',attr:'mostwatched'});
				$('[mostwatched]').show();
			}
		);	
		observer.observe(target, config);
	}
}

function createLnkRecording(divContainer, value){
	//Recording
	if(value == 0) return;
	lnk = document.createElement('a');
	lnk.innerHTML = 'Recording';
	lnk.id = 'lnkRecording';
	lnk.setAttribute('class', 'button filter');
	divContainer.appendChild(lnk);
	lnk.onclick = function(){
		observer.disconnect();
		sortChannels();
		clearFilters();
		$('#lnkHideChannels').text('Hide Channels');
		$('#lnkHideChannels').css('background', '');
		$(this).addClass('selected');
		$('.channel').hide();
		
		chrome.storage.sync.get(
			'recording', function (result) {
				if(result['recording'] === undefined) return;
				var arr = result['recording'].split(';');
				$('.badge.new, .badge.live').siblings('.listing-entity').addClass('htvlNew');
				for(var i = arr.length - 2; i >= 0; --i){
					$('*:contains(' + arr[i] + ')').addClass('rec');
				}
				$('.rec.htvlNew').parent().parent('.ShowMe').show();
				localStorage['xfinityView'] = '#lnkRecording';	
				window.scrollTo(0, 0);
			}
		);
		observer.observe(target, config);
	}
}

function createLnkLast(divContainer, value){
	//last
	if(value == 0) return;
	lnk = document.createElement('a');
	lnk.innerHTML = 'Last';
	lnk.id = 'lnkLast';
	lnk.setAttribute('class', 'button filter');
	divContainer.appendChild(lnk);
	lnk.onclick = function(){
		observer.disconnect();
		clearFilters();
		$('#lnkHideChannels').css('background', '');
		$('#lnkLast').addClass('selected');
		$('#lnkHideChannels').text('Hide Channels');
		//populate last watched class
		$('.watchedLast').removeClass('watchedLast');
		var channel;		
		localStorage['xfinityView'] = '#lnkLast';
		window.scrollTo(0, 0);
		
		chrome.storage.sync.get(
			null, function (items) {
				$('.channel').hide();
				if(items['last'] === undefined) return;
				var arr = items['last'].split(';');
				for(var i = arr.length - 2; i >= 0; --i){
					$('#' + arr[i]).addClass('watchedLast');
					channel = $('#' + arr[i])[0]
					channel.setAttribute('watchedLast', i);
				}
				
				$('.watchedLast').show();
				localStorage['unsorted'] = 'unsorted';
				$('.watchedLast').tsort({order:'desc',attr:'watchedLast'});
			}
		);
		observer.observe(target, config);
	}
}

function createLnkRemoveAllFavorites(divContainer, value){
	//remove favorites
	if(value == 0) return;
	lnk = document.createElement('a');
	lnk.innerHTML = 'Remove All Favorites';
	lnk.id = 'lnkRemoveAllFavorites';
	lnk.setAttribute('class',  'button filter');
	divContainer.appendChild(lnk);
	lnk.onclick = function(){
		var style;
		var display = '';
		var hoverRemove = document.getElementsByClassName('hover-remove');
		for (var i = hoverRemove.length -1; i >= 0; --i){
			style = window.getComputedStyle(hoverRemove[i]);
			display = style.getPropertyValue('display');
			if(display == 'block'){
				hoverRemove[i].click();
			}
		}
		window.scrollTo(0, 0);
	}
}

function createLnkFavorites(divContainer, value){
	//duplicate the favorites button
	//to avoid the annoying message box when there are no favorites
	$('.button.filter.favorites').remove();
	if(value == 0) return;
	lnk = document.createElement('a');
	lnk.innerHTML = 'Favorites';
	lnk.id = 'lnkFavorites';
	lnk.setAttribute('class', 'button filter favorites');
	divContainer.appendChild(lnk);
	var b = document.createElement('b');
	lnk.appendChild(b);
	lnk.onclick = function(){
		observer.disconnect();	
		clearFilters();
		sortChannels();
		$('.channel').hide();
		$('.ShowMe.fav').show();
		$('#lnkHideChannels').text('Hide Channels');
		$('#lnkHideChannels').css('background', '');
		$(this).addClass('selected');
		localStorage['xfinityView'] = '#lnkFavorites';
		window.scrollTo(0, 0);
		observer.observe(target, config);		
	}
}



if(debug) console.log('end script');