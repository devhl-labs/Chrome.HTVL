var debug = false;

var autoReload = true;

var lnkHd = 1;
var lnkFavorites = 1;
var lnkRemoveAllFavorites = 1;
var lnkHideChannels = 1;

var	lnkLast = 1;
var lastChannels = '';

var	lnkRecording = 1;
var	recordingShows = 'CNN Newsroom;SportsCenter';

var	lnkMostWatched = 1;
var mostWatchedChannels = '';

var	lnkMovies = 1;
var	lnkSports = 1;
var	lnkKids = 1;
	

var	strHidden ='288;329;602;028;831;995;095;996;096;999;099;063;881;690;192;112;107;324;037;889;540;498;868;041;989;592;636;114;583;726;058;115;103;029;714;713;715;855;855;922;654;588;732;661;159;645;647;480;146;053;054;570;817;060;122;941;942;615;007;846;644;020;104;105;660;643;113;062;593;880;125;135;641;039;575;869;287;877;046;622;998;098;150;986;701;702;703;704;705;706;851;712;006;005;585;719;730;047;664;291;597;799;106;720;721;722;670;056;820;044;839;231;584;627;032;857;148;009;824;725;567;771;772;773;774;775;776;777;778;779;682;780;781;782;783;784;669;789;790;003;849;651;066;116;157;301;311;491;801;487;488;901;785;490;043;838;875;038;577;579;064;055;717;023;088;808;130;993;111;164;501;167;502;072;543;069;025;184;587;992;027;204;119;802;845;004;021;320;322;233;319;437;413;418;412;422;447;407;448;424;449;427;450;429;417;431;416;433;415;435;414;401;421;439;423;441;425;443;411;445;410;426;409;430;402;434;408;438;403;442;446;432;419;406;420;405;436;428;444;440;404;176;738;327;321;366;151;499;315;812;052;049;605;601;328;863;749;002;848;733;860;246;861;263;734;871;109;739;061;616;330;607;728;155;123;626;549;544;882;662;663;016;806;679;657;637;635;655;110;872;696;341;346;342;340;238;339;987;089;283;347;888;990;988;191;694;736;030;693;128;370;372;375;374;371;369;248;373;571;623;031;829;033;826;297;036;008;751;752;753;754;755;756;757;758;759;620;633;547;735;652;040;837;604;566;760;325;350;351;352;787;787;862;034;825;065;141;991;045;035;680;695;612;618;100;674;621;057;822;564;562;189;010;823;559;870;050;545;594;649;611;011;208;811;015;805;117;051;026;800;561;018;017;019;807;108;013;813;668;012;563;022;014;804;294;689;198;196;024;803;565;981;960;970;186;550;001;548;542;691;850';

var b0 = 0;
var btitle0 = 'NCAA Baseball';
var bterms0 = 'College Baseball';

var b1 = 1;
var btitle1 = 'MLB';
var bterms1 = 'MLB Baseball';

var b2 = 0;
var btitle2 = 'NBA';
var bterms2 = 'NBA Playoff';

var b3 = 0;
var btitle3 = 'NHL';
var bterms3 = 'Stanley Cup Playoff;Stanley Cup Final;NHL Hockey';

var b4 = 1;
var btitle4 = 'NFL';
var bterms4 = 'NFL Draft;NFL Football;Sunday Night Football;Thursday Night Football;Monday Night Football';

var b5 = 0;
var btitle5 = 'College Football';
var bterms5 = 'College Football';

var b6 = 0;
var btitle6 = '';
var bterms6 = '';

var b7 = 0;
var btitle7 = '';
var bterms7 = '';

var b8 = 0;
var btitle8 = '';
var bterms8 = '';

var b9 = 0;
var btitle9 = 'test';
var bterms9 = 'Weatherscan;Paid Programming;CNN Newsroom;Community Channel';

var numOfChannels = 0;




function setSyncDefaults(callback){
	chrome.storage.sync.get(
		null, function (result) {
          debug = setSyncDefaultsSub(result, debug, 'debug');

          autoReload = setSyncDefaultsSub(result, autoReload, 'autoReload');

          lnkHd = setSyncDefaultsSub(result, lnkHd, 'lnkHd');
          lnkFavorites = setSyncDefaultsSub(result, lnkFavorites, 'lnkFavorites');
          lnkRemoveAllFavorites = setSyncDefaultsSub(result, lnkRemoveAllFavorites, 'lnkRemoveAllFavorites');
          lnkHideChannels = setSyncDefaultsSub(result, lnkHideChannels, 'lnkHideChannels');

          lnkLast = setSyncDefaultsSub(result, lnkLast, 'lnkLast');
          lastChannels = setSyncDefaultsSub(result, lastChannels, 'lastChannels');

          lnkRecording = setSyncDefaultsSub(result, lnkRecording, 'lnkRecording');
          recordingShows = setSyncDefaultsSub(result, recordingShows, 'recordingShows');

          lnkMostWatched = setSyncDefaultsSub(result, lnkMostWatched, 'lnkMostWatched');
          mostWatchedChannels = setSyncDefaultsSub(result, mostWatchedChannels, 'mostWatchedChannels');

          lnkMovies = lnkMovies = setSyncDefaultsSub(result, lnkMovies, 'lnkMovies');
          lnkSports = setSyncDefaultsSub(result, lnkSports, 'lnkSports');
          lnkKids = setSyncDefaultsSub(result, lnkKids, 'lnkKids');


          strHidden = setSyncDefaultsSub(result, strHidden, 'strHidden');

          b0 = setSyncDefaultsSub(result, b0, 'b0');
          btitle0 = setSyncDefaultsSub(result, btitle0, 'btitle0');
          bterms0 = setSyncDefaultsSub(result, bterms0, 'bterms0');

          b1 = setSyncDefaultsSub(result, b1, 'b1');
          btitle1 = setSyncDefaultsSub(result, btitle1, 'btitle1');
          bterms1 = setSyncDefaultsSub(result, bterms1, 'bterms1');


          b2 = setSyncDefaultsSub(result, b2, 'b2');
          btitle2 = setSyncDefaultsSub(result, btitle2, 'btitle2');
          bterms2 = setSyncDefaultsSub(result, bterms2, 'bterms2');

          b3 = setSyncDefaultsSub(result, b3, 'b3');
          btitle3 = setSyncDefaultsSub(result, btitle3, 'btitle3');
          bterms3 = setSyncDefaultsSub(result, bterms3, 'bterms3');

          b4 = setSyncDefaultsSub(result, b4, 'b4');
          btitle4 = setSyncDefaultsSub(result, btitle4, 'btitle4');
          bterms4 = setSyncDefaultsSub(result, bterms4, 'bterms4');

          b5 = setSyncDefaultsSub(result, b5, 'b5');
          btitle5 = setSyncDefaultsSub(result, btitle5, 'btitle5');
          bterms5 = setSyncDefaultsSub(result, bterms5, 'bterms5');

          b6 = setSyncDefaultsSub(result, b6, 'b6');
          btitle6 = setSyncDefaultsSub(result, btitle6, 'btitle6');
          bterms6 = setSyncDefaultsSub(result, bterms6, 'bterms6');

          b7 = setSyncDefaultsSub(result, b7, 'b7');
          btitle7 = setSyncDefaultsSub(result, btitle7, 'btitle7');
          bterms7 = setSyncDefaultsSub(result, bterms7, 'bterms7');

          b8 = setSyncDefaultsSub(result, b8, 'b8');
          btitle8 = setSyncDefaultsSub(result, btitle8, 'btitle8');
          bterms8 = setSyncDefaultsSub(result, bterms8, 'bterms8');

          b9 = setSyncDefaultsSub(result, b9, 'b9');
          btitle9 = setSyncDefaultsSub(result, btitle9, 'btitle9');
          bterms9 = setSyncDefaultsSub(result, bterms9, 'bterms9');

          numOfChannels = setSyncDefaultsSub(result, numOfChannels, 'numOfChannels');
          
          
          if(callback) callback();
		}
	);
}

function setSyncDefaultsSub(result, varVariable, strVariable){
	if(result[strVariable] === undefined){
		//console.log(strVariable + ' was undefined.  setting now');
		setKey(strVariable, varVariable);
        return strVariable;
	}else{
		//console.log(strVariable + ' was NOT undefined.  value was: ' + result[strVariable]);
       return result[strVariable];
	}
}


function setKey(key, value){
	var obj = {};
	obj[key] = value;
	chrome.storage.sync.set(obj);
}

function printSync(detail){
//for debugging only
//just prints the sync values to the console
//printSync();
//printSync('true');
	if(typeof detail === 'undefined'){
		chrome.storage.sync.get(null, function (data) { console.info(data) });
	}else{
		chrome.storage.sync.get(
			null, function (items) {
				for(var key in items){
					console.log(key + ' ' + items[key]);
				}
			}
		);
	}
}