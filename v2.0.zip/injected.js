//function test(){
//
//
//console.log('working');
//
//
//}
//$( "#lnkTest" ).on( "click", function() {
//     //console.log(CIM.rs.getDeviceByName('Like a Boss'));
//     new CIM.Rtune.TuneEvent({
//                    type: "linear",
//                    program: $("[data-vcn='042']").find('.hover-watch'),
//                    device: User.devices ? User.devices.rtune.getDefault() : {}
//                }).proceed()
//
////console.log(CIM.rs.getDeviceByName('Like a Boss'));
////new CIM.rtune.TuneEvent({program: $("[data-vcn='042']").parent().find('.hover-watch').data(), device: CIM.rs.getDeviceByName('Like a Boss')})
////console.log('worked');
//}
//);
    