"use strict";

var wrapper;
var lnk;
var divContainer = document.getElementsByClassName('option-filters')[0];
var br;

setSyncDefaults(start);

function start(){
//$(document).ready(function(){
     if(debug) console.log('document is ready, creating buttons');
     setTimer();
     createOptionsButton();
     createLoadingButton();
     createHideChannelsButton();
     createBrandingButton();
     createMostWatchedChannelsButton();
     createRecordingShowsButton();
     createLastChannelsButton();
     createFavoritesButton();
     createHdButton();
     createAlphabetizeButton();
     createRemoveFavoritesButton();
     createPrintSyncButton();
     createClearSyncButton();
        
     if(customFiltersActive()){
          var hr = document.createElement('hr');
          divContainer.appendChild(hr);
          createSportsButtons();
     }
     toggleDefaultFilters();
     
     
     watchChannelListener();
     //createMutationObserver();
     watchForLoadingChannels();
     watchForMouseHover();
//                         $('.channel-button-hover').on('mouseover', function(){
//                              console.log('mouseover');
//                              //init();
//                         });
//$(".channels").bind("DOMSubtreeModified", function() {
//    console.log("tree changed");
//    init();
//});

     
     var $filters = $('[data-filter]');
     $filters.bind(
          "click", function(){
               $('.selected').removeClass('selected');
               $('#lnkHideChannels').text('Hide Channels');
               $('#lnkHideChannels').css('background', '');
               $('.channel').hide();
               var filter = $(this).attr('data-filter');
               $('.' + filter + '.ShowMe').show();
               $('.channels').css({'min-height': '1000px'});
               $('[data-filter="' + $(this).attr('data-filter') + '"]');
          }
     );

//     $('.button.filter.hd').bind(
//          "click", function(){
//               //localStorage['htvlView'] = '#lnkHd';
//               //$('#lnkHideChannels').css('background', '');
//          }
//     );
//     $('.button.filter.movies').bind(
//          "click", function(){
//               localStorage['htvlView'] = '#lnkMovies';
//          }
//     );
//     $('.button.filter.sports').bind(
//          "click", function(){
//               localStorage['htvlView'] = '#lnkSports';
//          }
//     );
//     $('.button.filter.kids').bind(
//          "click", function(){
//               localStorage['htvlView'] = '#lnkKids';
//          }
//     ); 
     
     //hide the My Channels button
     $('[data-filter="my-channels"]').hide();
     
     
     chrome.runtime.sendMessage({version: 1.1}, 
          function(response) {
               if(response.farewell) alert('Thank you for updating htvl.\nButtons have been tweeked.\nSorting by name or channel is an option now.');
          }
     );
     
     //createTestButton();
     
     
     
     var s = document.createElement('script');
     s.src = chrome.extension.getURL('injected.js');
     s.onload = function() {
          this.parentNode.removeChild(this);
     };
     (document.head||document.documentElement).appendChild(s);





     
     
     if(debug) console.log('end document ready');
//});
}

