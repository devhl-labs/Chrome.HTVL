//these are used by the mutation observer
//var observer;
var observeLoad;
var observeHover;
var target;
var configLoad;
var configHover;

var sorted = 'sorted';

function setTimer() {
     if(!autoReload) return;
     var d = new Date(),
     h = new Date(d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), (d.getMinutes() - (d.getMinutes() % 30)) + 30, 0, 0),
     e = h - d;
     window.setTimeout(function(){
          location.reload()
     }, e);
}

function createOptionsButton(){
     wrapper = document.getElementsByClassName('change-location-wrapper')[0];
     lnk = document.createElement('a');
     lnk.id = 'lnkOptions';
     lnk.innerHTML = 'htvl Options';
     lnk.className = 'print-button';
     lnk.setAttribute('style', 'cursor: pointer;');
     lnk.href = chrome.extension.getURL('htvlOptions.html');
     lnk.target = '_blank';
     wrapper.appendChild(lnk);     
}

function createLoadingButton(){
     lnk = document.createElement('a');
     lnk.id = 'lnkLoading';
     var strLoading = localStorage['htvlView'];
     var $selectedFilter = $('.selected[data-filter]');
     if($selectedFilter.length){
          strLoading = $selectedFilter.text();
     }
     lnk.innerHTML = 'Please Wait...loading ' //+ localStorage['htvlView'].replace('#lnk', '');
     lnk.className = 'print-button';
     wrapper.appendChild(lnk);
}

function createHideChannelsButton(){
     //hide channels
     lnk = document.createElement('a');
     lnk.id='lnkHideChannels';
     lnk.setAttribute('class',  'button filter');
     lnk.innerHTML = 'Show Hidden';
     divContainer.appendChild(lnk);
// 	 lnk.onclick = function(){
//		//observer.disconnect();
//       toggleObservers(false);
//		sortChannels();
//		clearFilters();
//		window.scrollTo(0, 0);
//		$('.selected').removeClass('selected');
//		$('#lnkHideChannels').addClass('selected');
//        $('.channel').show();
//		if($('#lnkHideChannels').text() == 'Hide Channels'){
//           $('.HideMe').hide();
//			$('#lnkHideChannels').text('Show Hidden');
//			$('#lnkHideChannels').attr('style', 'background:-webkit-linear-gradient(top,#006fa8 0,#0094cd 100%))');
//		}else{
//			$('#lnkHideChannels').text('Hide Channels');
//			$('#lnkHideChannels').attr('style', 'background:-webkit-linear-gradient(top,#400101 0,#EB1A1A 100%)');
//			$('.channel').show();
//		}
//		//observer.observe(target, config);
//       toggleObservers(true);
//	}
     lnk.onclick = function(){
          toggleObservers(false);
          window.scrollTo(0, 0);
          $('.channel').show();
          $('.selected').removeClass('selected');
          $('#lnkHideChannels').addClass('selected');
          if($('#lnkHideChannels').text() == 'Hide Channels'){
               $('.HideMe').hide();
               $('#lnkHideChannels').attr('style', 'background:-webkit-linear-gradient(top,#006fa8 0,#0094cd 100%))');
               $('#lnkHideChannels').text('Show Hidden');
          }else{
               $('.HideMe').show(); 
               $('#lnkHideChannels').text('Hide Channels');
               $('#lnkHideChannels').attr('style', 'background:-webkit-linear-gradient(top,#400101 0,#EB1A1A 100%)');
          }
       toggleObservers(true);
     };
}

function createAlphabetizeButton(){
     lnk = document.createElement('a');
     lnk.id='lnkSort';
     lnk.setAttribute('class',  'button filter');
     lnk.innerHTML = 'Sort By Name';
     divContainer.appendChild(lnk);
 	lnk.onclick = function(){
          toggleObservers(false);
		if($('#lnkSort').text() == 'Sort By Name'){
			$('#lnkSort').text('Sort By Number');
			$('.channel').tsort({attr:'data-callsign'});
		}else{
			$('#lnkSort').text('Sort By Name');
			$('.channel').tsort({attr:'data-vcn'});
		}
       toggleObservers(true);
       sorted = 'sorted';
	}
}

function createBrandingButton(){
     //Create branding link
     var divSearch = document.getElementsByClassName('options')[0];
     br = document.createElement('br');
     divSearch.appendChild(br);
	
     lnk = document.createElement('a');
     lnk.innerHTML = 'More From Developer';
     lnk.setAttribute('class', 'button filter');
     //lnk.href = chrome.extension.getURL('appsFromDeveloper/appsFromDeveloper.html');
     lnk.href="http://www.devhl.com/";
     lnk.target = '_blank';
     divSearch.appendChild(lnk);
}

function createPrintSyncButton(){
     //Create the print sync button
     if(!debug) return;
     lnk = document.createElement('a');
     lnk.innerHTML = 'printSync';
     lnk.id = 'lnkPrintSync';
     lnk.setAttribute('class', 'button filter');
     if(debug) divContainer.appendChild(lnk);
     lnk.onclick = function(){
          printSync('a');
     }
}

function createClearSyncButton(){
     if(!debug) return;
     lnk = document.createElement('a');
     lnk.innerHTML = 'clearSync';
     lnk.id = 'lnkClearSync';
     lnk.setAttribute('class', 'button filter');
     if(debug) divContainer.appendChild(lnk);
     lnk.onclick = function(){
          chrome.storage.sync.clear();
          console.log('cleared');
     }
}     

function createRemoveFavoritesButton(){
     //remove favorites
     if(!lnkRemoveAllFavorites) return;
     lnk = document.createElement('a');
     lnk.innerHTML = 'Remove All Favorites';
     lnk.id = 'lnkRemoveAllFavorites';
     lnk.setAttribute('class',  'button filter');
     divContainer.appendChild(lnk);
     lnk.onclick = function(){
          var style;
          var display = '';
          var hoverRemove = document.getElementsByClassName('hover-remove');
          for (var i = hoverRemove.length - 1; i >= 0; --i){
               style = window.getComputedStyle(hoverRemove[i]);
               display = style.getPropertyValue('display');
               if(display == 'block'){
                    hoverRemove[i].click();
               }
          }
     };
}

function createSportsButtons(){
     for(var i = 0; i < 10; ++i){
          if(eval('b' + i) == 0) continue;
          lnk = document.createElement('a');
          var title = eval('btitle' + i);
          if(title.length == 0) title = 'No Title Entered';
          lnk.innerHTML = title;
          lnk.setAttribute('class', 'button filter');
          lnk.id = 'b' + i;
          lnk.setAttribute('searchTerms', eval('bterms' + i))
          divContainer.appendChild(lnk);	
          lnk.onclick = function(){
               //observer.disconnect();		
               toggleObservers(false);
               clearFilters();
               sortChannels();
               $('.selected').removeClass('selected');
               $(this).addClass('selected');
               $('#lnkHideChannels').text('Hide Channels');
               $('#lnkHideChannels').css('background', '');
               $('.channel').hide();     
               $('#lnkLoading').show();
               window.scrollTo(0, 0);
               var arr = $(this).attr('searchTerms').split(';');
               for(var i = arr.length - 1; i >= 0; --i){
                    $('.listing-entity:contains(' + arr[i] + ')').parent().parent('.ShowMe').show();
               }						
               $('#lnkLoading').hide();
               //observer.observe(target, config);
               toggleObservers(true);
               $('#channels-filters-empty').attr('style', 'display: none');
               if(debug) console.log('searchTerms: ' + $(this).attr('searchTerms'));
          }
     }
}

function createMostWatchedChannelsButton(){
     //most watched
     if(lnkMostWatched == 0) return;
     lnk = document.createElement('a');
     lnk.innerHTML='Most Watched';
     lnk.id = 'lnkMostWatched';
     lnk.setAttribute('class', 'button filter');
     divContainer.appendChild(lnk);
     lnk.onclick = function(){
          //observer.disconnect();	
          toggleObservers(false);
          clearFilters();
          $('#lnkMostWatched').addClass('selected');
          $('.channel').hide();
          $('#lnkHideChannels').text('Hide Channels');
          $('#lnkHideChannels').css('background', '');
          window.scrollTo(0, 0);
		
		 if(mostWatchedChannels == '') return;
           
          var arr = mostWatchedChannels.split(';');
          var arr2;
          $('*').removeAttr('mostwatched');
          for(var i = arr.length - 1; i >= 0; --i){
               arr2 = arr[i].split('=');
               $('[data-vcn="' + arr2[0] + '"]').first().attr('mostwatched', arr2[1]);
          }
          sorted = 'unsorted';
          $('[mostwatched]').tsort({
               order:'desc',
               attr:'mostwatched'
          });
          $('.ShowMe[mostwatched]').show();
          //observer.observe(target, config);
          toggleObservers(true);
          if(debug) console.log('mostWatchedChannels: ' + mostWatchedChannels);	
     }
}

function createRecordingShowsButton(){
     //Recording
     if(lnkRecording == 0) return;
     lnk = document.createElement('a');
     lnk.innerHTML = 'Recording';
     lnk.id = 'lnkRecording';
     lnk.setAttribute('class', 'button filter');
     divContainer.appendChild(lnk);
     lnk.onclick = function(){
          //observer.disconnect();
          toggleObservers(false);
          sortChannels();
          clearFilters();
          $('#lnkHideChannels').text('Hide Channels');
          $('#lnkHideChannels').css('background', '');
          $(this).addClass('selected');
          $('.channel').hide();
          if(recordingShows == '') return;
          var arr = recordingShows.split(';');
          for(var i = arr.length - 1; i >= 0; --i){
               $('.listing-entity:contains(' + arr[i] + ')').addClass('htvlrec');
          }
          $('.htvlrec').parent('.new, .live').parent('.ShowMe').show();	
          window.scrollTo(0, 0);
          //observer.observe(target, config);
          toggleObservers(true);
          if(debug) console.log('recordingShows: ' + recordingShows);
     }
}

function createLastChannelsButton(){
     if(lnkLast == 0) return;
     lnk = document.createElement('a');
     lnk.innerHTML = 'Last';
     lnk.id = 'lnkLast';
     lnk.setAttribute('class', 'button filter');
     divContainer.appendChild(lnk);
     lnk.onclick = function(){
          //observer.disconnect();
          toggleObservers(false);
          clearFilters();
          $('#lnkHideChannels').css('background', '');
          $('#lnkLast').addClass('selected');
          $('#lnkHideChannels').text('Hide Channels');
          $('.watchedLast').removeClass('watchedLast');	
          window.scrollTo(0, 0);
		
          $('.channel').hide();
          if(lastChannels === '') return;
          var arr = lastChannels.split(';');

          for(var i = arr.length - 1; i >= 0; --i){
               $('[data-vcn="' + arr[i] + '"]').first().addClass('watchedLast');
               $('[data-vcn="' + arr[i] + '"]').first().attr('watchedLast', i);
          }

          $('.ShowMe.watchedLast').show();
          sorted = 'unsorted';
          $('.watchedLast').tsort({
               order:'asc',
               attr:'watchedLast'
          });
          //observer.observe(target, config);
          toggleObservers(true);
          
          if(debug) console.log('lastChannels: ' + lastChannels);
     }
}

function createFavoritesButton(){
     //duplicate the favorites button
     //to avoid the annoying message box when there are no favorites
     $('.button.filter.favorites').remove();
     if(lnkFavorites == 0) return;
     lnk = document.createElement('a');
     lnk.innerHTML = 'Favorites';
     lnk.id = 'lnkFavorites';
     lnk.setAttribute('class', 'button filter favorites');
     divContainer.appendChild(lnk);
     var span = document.createElement('span');
     span.className='font-icon-heart';
     lnk.appendChild(span);
     lnk.onclick = function(){
          //observer.disconnect();	
          toggleObservers(false);
          clearFilters();
          sortChannels();
          $('.channel').hide();
          $('.ShowMe.fav').show();
          $('#lnkHideChannels').text('Hide Channels');
          $('#lnkHideChannels').css('background', '');
          $(this).addClass('selected');
          window.scrollTo(0, 0);
          //observer.observe(target, config);		
          toggleObservers(true);
     }
}

function createHdButton(){
     //duplicate the hd button
     //to avoid a bug with the default hd button
     $('.button.filter.hd').remove();
     if(lnkHd == 0) return;
     lnk = document.createElement('a');
     lnk.innerHTML = 'HD Only';
     lnk.id = 'lnkHd';
     lnk.setAttribute('class', 'button filter hd');
     divContainer.appendChild(lnk);
     var span = document.createElement('span');
     span.setAttribute('class', 'font-icon-hd');
     lnk.appendChild(span);
     lnk.onclick = function(){
          //observer.disconnect();	
          toggleObservers(false);
          clearFilters();
          sortChannels();
          $('.channel').hide();
          $('.channel.hd.ShowMe').show();
          $('#lnkHideChannels').text('Hide Channels');
          $('#lnkHideChannels').css('background', '');
          $(this).addClass('selected');
          window.scrollTo(0, 0);
          //observer.observe(target, config);		
          toggleObservers(true);
     }
}

function customFiltersActive(){
     for(var i = 0; i < 10; ++i){
          if(eval('b' + i) == 1){
               return true;
               break;
          }
     }
     return false;
}

function toggleDefaultFilters(){
//     var i;
//     if(lnkMovies == 0){
//          i = 1;
//          $('.button.filter.movies').hide(); 
//     }
//     if(lnkSports == 0){
//          i += 1;
//          $('.button.filter.sports').hide(); 
//     }     
//     if(lnkKids == 0){
//          i += 1;
//          $('.button.filter.kids').hide(); 
//     }     
//     if(i == 3) $('.button.filter.movies').parent().prev().hide();
     
     $('.button.filter.movies').hide(); 
     $('.button.filter.sports').hide();
     $('.button.filter.kids').hide();
     var divExclusive = $('.option-filters.exclusive');
     
     var i = 0;
     if(lnkMovies){
          lnk = document.createElement('a');
          lnk.innerHTML = 'Movies'
          lnk.id = 'lnkMovies';
          lnk.setAttribute('class', 'button filter movies');
          lnk.setAttribute('style', 'margin-left: 15px;');
          lnk.setAttribute('title', 'Movies');
          divExclusive.append(lnk);
          var span = document.createElement('span');
          span.setAttribute('class', 'font-icon-movies');
          lnk.appendChild(span);
          i = 1;
          lnk.onclick = function(){
               $('.channel').hide();
               $('.listing.movies').parent('.ShowMe').show();
               $('#lnkHideChannels').text('Hide Channels');
               clearFilters();
               $(this).addClass('selected');
               	
          }          
     }
     if(lnkSports){
          lnk = document.createElement('a');
          lnk.innerHTML = 'Sports'
          lnk.id = 'lnkMovies';
          lnk.setAttribute('class', 'button filter sports');
          //lnk.setAttribute('data-filter', 'sports');
          lnk.setAttribute('title', 'Sports');
          divExclusive.append(lnk);
          span = document.createElement('span');
          span.setAttribute('class', 'font-icon-sports');
          lnk.appendChild(span);
          i = 1;
          lnk.onclick = function(){
               $('.channel').hide();
               $('.listing.sports').parent('.ShowMe').show();
               $('#lnkHideChannels').text('Hide Channels');
               clearFilters();
               $(this).addClass('selected');               	
          } 
     }     
     if(lnkKids){
          lnk = document.createElement('a');
          lnk.innerHTML = 'Kids'
          lnk.id = 'lnkMovies';
          lnk.setAttribute('class', 'button filter kids');
          lnk.setAttribute('title', 'Kids');
          divExclusive.append(lnk);
          span = document.createElement('span');
          span.setAttribute('class', 'font-icon-kids');
          lnk.appendChild(span);
          i = 1;
          lnk.onclick = function(){
               $('.channel').hide();
               $('.listing.kids').parent('.ShowMe').show();
               $('#lnkHideChannels').text('Hide Channels');
               clearFilters();
               $(this).addClass('selected');               	
          }                    
     }
     if(i == 0) divExclusive.next().hide();
}


//////////////////////INITIALIZE CHANNELS//////////////////////////////
function watchForLoadingChannels(){
     //create an observer to watch for changes to the dom
     //this is how we know when channels are loaded
     //this is where we will hide channels
     target = document.querySelector('.channels');
     observeLoad = new MutationObserver(
          function(mutations) {
               mutations.forEach(
                    function(mutation) {
                         if(debug) console.log('initializing ' + $('.channel').length + ' channels');
                         setKey('numOfChannels', $('.channel').length);
                         if($('.channel').length == numOfChannels){
                              $('#lnkLoading').hide();
                         }else{
                              $('#lnkLoading').show();
                         }
                         //console.log(mutation.addedNodes[0]);
//                         if(strHidden.indexOf($(channel).attr('data-vcn')) != -1){
//                              $hoverWatch.attr('style', 'width: 350px; background-color: DarkGray;');
//                              //$hoverWatch.parent().children('.channel-actions').children().attr('style', 'background-color: DarkGray;');
//                         }
                         
                         $('#lnkHideChannels').text('Hide Channels');
                         $('#lnkHideChannels').click();
                         init();
                    }
               );    
          }
     );
     configLoad = {
          attributes: false, 
          childList: true, 
          characterData: false, 
          subtree: false
     };
     observeLoad.observe(target, configLoad);
}

function watchForMouseHover(){
     //some nodes are created dynamically after the hover event
     //this will watch for the nodes and add the buttons to the hover div
     target = document.querySelector('.channels');
     observeHover = new MutationObserver(
          function(mutations) {
               mutations.forEach(
                    function(mutation) {
                         //if(debug) console.log('mouse hover');
                         //setKey('numOfChannels', $('.channel').length);
//                         if($('.channel').length == numOfChannels){
//                              $('#lnkLoading').hide();
//                         }else{
//                              $('#lnkLoading').show();
//                         }
//                         $('#lnkHideChannels').text('Hide Channels');
//                         $('#lnkHideChannels').click();
//                         init();
                           //modifyHoverDiv();
                           //console.log(mutation.addedNodes);
                           //console.log(mutation.addedNodes[0].parentNode);
                           modifyHoverDiv(mutation.addedNodes[0].parentNode);
                    }
               );    
          }
     );
     configHover = {
          attributes: false, 
          childList: true, 
          characterData: false, 
          subtree: true
     };
     observeHover.observe(target, configHover);
}

function modifyHoverDiv(channel){ 
     //small css changes
     $('.hover-add').css('border-left', '0px');
     $('.hover-remove').css('border-left', '0px');
//     $('.channels').css({
//          'min-height': '1000px'
//     });
//     $('.viewport').css({
//          'min-height': '1000px'
//     });
	
     var $hoverWatch;
  
     $hoverWatch = $(channel).find('.channel-button-hover');
     try{
          createHideMe($(channel), $hoverWatch);
          //console.log($(channel));
          createUnHide($(channel), $hoverWatch);
          createRemoveMostWatched($(channel), $hoverWatch);
          //$(this).addClass("processed");
     }catch(e){}              
     if(strHidden.indexOf($(channel).attr('data-vcn')) != -1){
          $hoverWatch.attr('style', 'width: 350px; background-color: DarkGray;');
          $hoverWatch.parent().children('.channel-actions').children().attr('style', 'background-color: DarkGray;');
     }else{
          $hoverWatch.attr('style', 'width: 350px');	
     }
                  
}


///////////////////PROCESS EVERY CHANNEL AND MAKE CHANGES/////////////
function init(){ 
     //small css changes
//     $('.hover-add').css('border-left', '0px');
//     $('.hover-remove').css('border-left', '0px');
     $('.channels').css({
          'min-height': '1000px'
     });
     $('.viewport').css({
          'min-height': '1000px'
     });
	
     var $channels = $('.channel').not('.processed');
     //var $hoverWatch;
  
     $channels.each(
          function(x){
               //$hoverWatch = $(this).find('.channel-button-hover');
               try{
                    //createHideMe($(this), $hoverWatch);
                    //createUnHide($(this), $hoverWatch);
                    //createRemoveMostWatched($(this), $hoverWatch);
                    $(this).addClass("processed");
               }catch(e){} 
               if(strHidden.indexOf($(this).attr('data-vcn')) != -1){
                    $(this).addClass('HideMe');
                    $(this).find('.channel-button').attr('style', 'background-color: DarkGray;');
               }else{
                    $(this).addClass('ShowMe');
                    //$hoverWatch.attr('style', 'width: 350px');	
               }
                  
          }
    );
}

function createHideMe($channel, $hoverWatch){
     var channel = $channel[0];
     var hoverWatch = $hoverWatch[0];
     var lnk = document.createElement('a');
     lnk.setAttribute('style', 'display: block; width: 41px; cursor: pointer;');
     lnk.innerHTML = 'Hide Me!';
     lnk.onclick = function(){
          hoverWatch.setAttribute('style', 'background-color: DarkGray; width: 324px;');
          $hoverWatch.parent().children('.channel-actions').children().attr('style', 'background-color: DarkGray;');
          channel.className = channel.className.replace(" ShowMe", " ");
          channel.className = channel.className.replace(" HideMe", " ");		
          channel.className = channel.className + " HideMe";
          if(strHidden.indexOf($(channel).attr('data-vcn')) == -1){ 
               strHidden = strHidden +  ";" + $(channel).attr('data-vcn');
               setKey('strHidden', strHidden);
          }
         // $(this).removeClass('ShowMe HideMe').addClass(' HideMe ');
     };
     hoverWatch.appendChild(lnk);
}

function createUnHide($channel, $hoverWatch){
     var channel = $channel[0];
     var hoverWatch = $hoverWatch[0];
     var lnk=document.createElement('a');
     lnk.setAttribute('style', 'display: block; width: 41px; cursor: pointer;');
     lnk.innerHTML = 'Unhide Me';
     lnk.onclick=function(){
          hoverWatch.setAttribute('style', 'width: 350px;');
          channel.className = channel.className.replace(" ShowMe", " ");
          channel.className = channel.className.replace(" HideMe", " ");		
          channel.className = channel.className + " ShowMe";
          $hoverWatch.parent().children('.channel-actions').children().removeAttr('style');	
          //this removes the channel id from the string if it is not the first one in the array
          if(strHidden.indexOf(';' + $(channel).attr('data-vcn')) != -1){  
               strHidden = strHidden.replace(';' + $(channel).attr('data-vcn'), '');
               setKey('strHidden', strHidden);
               
          }
          //this handles removing the channel when it is first in the array
          if(strHidden.indexOf($(channel).attr('data-vcn') + ';') != -1){  
               strHidden = strHidden.replace($(channel).attr('data-vcn') + ';', '');
               setKey('strHidden', strHidden);
          }
     };
     hoverWatch.appendChild(lnk);
}

function createRemoveMostWatched($channel, $hoverWatch){
     var channel = $channel[0];
     var hoverWatch = $hoverWatch[0];
     var lnk=document.createElement('a');
     lnk.innerHTML = '-Most Wtchd';
     lnk.setAttribute('style', 'display: block; width: 41px; cursor: pointer;');
     lnk.setAttribute('class', 'unHideChannels');
     lnk.onclick=function(){
          var arr = mostWatchedChannels.split(';');
          var arr2;
          for(var i = arr.length; i > 0; --i){
               arr2 = arr[i - 1].split('=');
               if(arr2[0] == $(channel).attr('data-vcn')){
                    arr.remove(i - 1);
                    mostWatchedChannels = arr.join(';');
                    setKey('mostWatchedChannels', mostWatchedChannels);
                    break;
               }
          }
          if(debug) console.log('mostWatchedChannels: ' + mostWatchedChannels);
     };
     hoverWatch.appendChild(lnk);
}

// Array Remove - By John Resig (MIT Licensed)
Array.prototype.remove = function(from, to) {
  var rest = this.slice((to || from) + 1 || this.length);
  this.length = from < 0 ? this.length + from : from;
  return this.push.apply(this, rest);
};

function watchChannelListener(){
     var $hoverWatch = $('.hover-watch');
     $hoverWatch.live(
          "click", function() {
               var $channel = $(this).parent().parent();

               //record last watched channel
               var arr = lastChannels.split(';');
               for(var i = arr.length; i > 0; --i){
                    if(arr[i - 1] == $channel.attr('data-vcn')){
                         arr.remove(i - 1);
                    }
               }
               arr.unshift($channel.attr('data-vcn'));
               lastChannels = arr.join(';');
               if(lastChannels.slice(-1) == ';') {                   
                    lastChannels = lastChannels.substring(0, lastChannels.length - 1);
               }           
               setKey('lastChannels', lastChannels);
               
               
               //record most watched
               if(mostWatchedChannels == '') {
                    mostWatchedChannels = $channel.attr('data-vcn') + '=1';
               }else{
                   arr = mostWatchedChannels.split(';');
                   var arr2;
                   var boo = false;
                   for(i = arr.length; i > 0; --i){
                         arr2 = arr[i - 1].split('=');
                         if(arr2[0] == $channel.attr('data-vcn')){
                              var newInt = parseInt(arr2[1]) + 1;
                              arr2[1] = newInt;
                              arr[i - 1] = arr2.join('=');
                              mostWatchedChannels = arr.join(';');
                              boo = true;
                              break;
                         }
                   }
                   if(!boo){
                         mostWatchedChannels = mostWatchedChannels + ';' + $channel.attr('data-vcn') + '=1';
                   }
               }
               setKey('mostWatchedChannels', mostWatchedChannels);
              
               if(debug) console.log('mostWatchedChannels: ' + mostWatchedChannels);
               if(debug) console.log('lastChannels: ' + lastChannels);
          }
     )
          
}

function sortChannels(){
//	if(localStorage['htvlUnsorted'] == 'unsorted'){
//		$('.channel').tsort({attr:'id'});
//		localStorage['htvlUnsorted'] = 'sorted';
//	}
     if(sorted != 'sorted'){
          $('.channel').tsort({attr:'data-vcn'});
          sorted = 'sorted';
     }
}

function sortChannelNames(){
//	if(localStorage['htvlUnsorted'] == 'unsorted'){
//		$('.channel').tsort({attr:'id'});
//		localStorage['htvlUnsorted'] = 'sorted';
//	}
     //if(sorted != 'sorted'){
          $('.channel').tsort({attr:'data-callsign'});
     //     sorted = 'sorted';
     //}
}

function clearFilters(){
	try{
		$('.selected[data-filter]')[0].click();
	}catch(e){
	}
	$('.selected').removeClass('selected');
}

function toggleObservers(boo){
     if (boo == true){
          observeLoad.observe(target, configLoad);
          observeHover.observe(target, configHover);
          if(debug) console.log('started observing');
     }
     if(boo != true){
          observeLoad.disconnect();
          observeHover.disconnect();
          if (debug) console.log('stopped observing');
     }
     
     $('#channels-filters-empty').hide();
}

function createTestButton(){
     wrapper = document.getElementsByClassName('change-location-wrapper')[0];
     lnk = document.createElement('a');
     lnk.id = 'lnkTest';
     lnk.innerHTML = 'Test';
     lnk.className = 'print-button';
     lnk.setAttribute('style', 'cursor: pointer;');
     lnk.target = '_blank';
     wrapper.appendChild(lnk);  
//     lnk.onclick = function(){
////          console.log('working');
////          console.log(CIM.rs.getDeviceByName('Like a Boss'));
////          console.log('working2');
//test();
//	}
}



































