//previous version that is no longer published, no longer used
chrome.management.setEnabled('gnbeokkohplojcckboakfdippdeclilo', false);


chrome.runtime.onMessage.addListener(
     function(request, sender, sendResponse) {
          var boo = false;
          if(!localStorage['htvlVersion']) {
               localStorage['htvlVersion'] = 1.1;
               boo = true;
          }
          if(localStorage['htvlVersion'] != request.version){
               localStorage['htvlVersion'] = request.version
               boo = true;
          }
          console.log(boo);
          console.log(request.version);
          if (boo) sendResponse({farewell: "goodbye"});
     }
);

