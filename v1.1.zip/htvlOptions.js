setSyncDefaults(start);
$('#lnkEnableButtons').click();

function start(){
     if(debug) console.log('sync values have been retrieved.');
     x
     if(debug) $('#debug').prop('checked', true);
     if(autoReload) $('#autoReload').prop('checked', true);
     if(lnkHd) $('#lnkHd').prop('checked', true);
     if(lnkFavorites) $('#lnkFavorites').prop('checked', true);
     if(lnkRemoveAllFavorites) $('#lnkRemoveAllFavorites').prop('checked', true);
     if(lnkLast) $('#lnkLast').prop('checked', true);
     if(lnkMostWatched) $('#lnkMostWatched').prop('checked', true);
     if(lnkMovies) $('#lnkMovies').prop('checked', true);
     if(lnkSports) $('#lnkSports').prop('checked', true);
     if(lnkKids) $('#lnkKids').prop('checked', true);

     if(lnkRecording) $('#lnkRecording').prop('checked', true);

     if(b0) $('#b0').prop('checked', true);
     if(b1) $('#b1').prop('checked', true);
     if(b2) $('#b2').prop('checked', true);
     if(b3) $('#b3').prop('checked', true);
     if(b4) $('#b4').prop('checked', true);
     if(b5) $('#b5').prop('checked', true);
     if(b6) $('#b6').prop('checked', true);
     if(b7) $('#b7').prop('checked', true);
     if(b8) $('#b8').prop('checked', true);
     if(b9) $('#b9').prop('checked', true);

     var arr = recordingShows.split(';');
     for(var i = 0; i <= arr.length - 1; ++i){
          addRecordingRow(arr[i]);
     }
     addRecordingRow();
     addRecordingRow();
     addRecordingRow();

     var arrHidden = strHidden.split(';').sort().reverse();
     for(i = arrHidden.length - 1; i > 0; --i){
          $('#hiddenChannels').append(arrHidden[i] + '<br />');
     }

     $('#btitle0').val(btitle0);
     arr = bterms0.split(';');
     for(i = 0; i <= arr.length - 1; ++i){
          addSearchTerm($('#tblb0'), 0, arr[i]);
     }

     $('#btitle1').val(btitle1);
     arr = bterms1.split(';');
     for(i = 0; i <= arr.length - 1; ++i){
          addSearchTerm($('#tblb1'), 1, arr[i]);
     }

     $('#btitle2').val(btitle2);
     arr = bterms2.split(';');
     for(i = 0; i <= arr.length - 1; ++i){
          addSearchTerm($('#tblb2'), 2, arr[i]);
     }

     $('#btitle3').val(btitle3);
     arr = bterms3.split(';');
     for(i = 0; i <= arr.length - 1; ++i){
          addSearchTerm($('#tblb3'), 3, arr[i]);
     }

     $('#btitle4').val(btitle4);
     arr = bterms4.split(';');
     for(i = 0; i <= arr.length - 1; ++i){
          addSearchTerm($('#tblb4'), 4, arr[i]);
     }

     $('#btitle5').val(btitle5);
     arr = bterms5.split(';');
     for(i = 0; i <= arr.length - 1; ++i){
          addSearchTerm($('#tblb5'), 5, arr[i]);
     }

     $('#btitle6').val(btitle6);
     arr = bterms6.split(';');
     for(i = 0; i <= arr.length - 1; ++i){
          addSearchTerm($('#tblb6'), 6, arr[i]);
     }

     $('#btitle7').val(btitle7);
     arr = bterms7.split(';');
     for(i = 0; i <= arr.length - 1; ++i){
          addSearchTerm($('#tblb7'), 7, arr[i]);
     }

     $('#btitle8').val(btitle8);
     arr = bterms0.split(';');
     for(i = 0; i <= arr.length - 1; ++i){
          addSearchTerm($('#tblb8'), 8, arr[i]);
     }

     $('#btitle9').val(btitle9);
     arr = bterms9.split(';');
     for(i = 0; i <= arr.length - 1; ++i){
          addSearchTerm($('#tblb9'), 9, arr[i]);
     }

     //add three blank rows for each custom filter
     for(var x = 0; x < 10; ++x){
               addSearchTerm($('#tblb' + x), x);
               addSearchTerm($('#tblb' + x), x);
               addSearchTerm($('#tblb' + x), x);							
     }

     $('option[value=0]').text(btitle0);
     $('option[value=1]').text(btitle1);
     $('option[value=2]').text(btitle2);
     $('option[value=3]').text(btitle3);
     $('option[value=4]').text(btitle4);
     $('option[value=5]').text(btitle5);
     $('option[value=6]').text(btitle6);
     $('option[value=7]').text(btitle7);
     $('option[value=8]').text(btitle8);
     $('option[value=9]').text(btitle9);
     
     
     
     $('#numOfChannels').text(numOfChannels);
}






function addSearchTerm($tbl, x, value){
	var tr = document.createElement('tr');
	var td = document.createElement('td');
	var input = document.createElement('input');
	var text = document.createTextNode('term');
	input.setAttribute('type', 'text');
	input.className = 'b' + x + 'term';
	$tbl.append(tr);
	tr.appendChild(td);
	td.appendChild(text);
	td = document.createElement('td');
	tr.appendChild(td);
	td.appendChild(input);
	if(value !== undefined) input.value = value;
	input.onchange = function(){
		var str = '';
		var len = $('.b' + x + 'term').length;
		$('.b' + x + 'term').each(
			function(i){
				if($(this).val()) str += $(this).val() + ';';
			}
		);
		str = str.slice(0, -1); 
		setKey('bterms' + x, str);
	}
}

function addRecordingRow(value){
	var $table = $('#tblRecording');
	var tr = document.createElement('tr');
	
	$table.append(tr);
	var td = document.createElement('td');
	tr.appendChild(td);
	var input = document.createElement('input');
	input.className = 'recording';
	if(typeof value === 'string')input.value = value;
	td.appendChild(input);
	var str = '';
	input.onchange = function (){
		str = '';
		$('.recording').each(
			function(i){
				if($(this).val().length > 0) str += $(this).val() + ';';
			}
		);
		str = str.slice(0, -1);
		setKey('recordingShows', str);
	}

}

function hideMenus(){
	$('#controls').hide();
	$('#recordings').hide();
	$('#customFilters').hide();
	$('#otherOptions').hide();
	$('#help').hide();
	$('#hidden').hide();
}

////////////////Bindings////////////////////////////////
$('.title').bind(
	'change', function(){
		setKey($(this).attr('id'), $(this).val());
	}
);

$('.toggle').bind(
	'change', function() {
		var value = 0;
		if($(this).attr('checked') == 'checked'){
			value = 1;
		}else{
			value = 0;
		}
		
		setKey(this.id, value);
          console.log(this.id + ' ' + value);
	}
);

$('#ClearHidden').bind(
        'click',function(){
               if(confirm('Click ok to erase all hidden channels.\nYou will have to manually set all hidden channels.')){
                         setKey('strHidden','0;');
                    };
        }
);

$('#lnkBranding').bind(
	'click', function(){
		//window.location = chrome.extension.getURL('appsFromDeveloper/appsFromDeveloper.html');
          chrome.tabs.update({
               url: "http://www.devhl.com/"
          });          
	}
);

$('#clearChannelNumber').bind(
	'click', function(){
		setKey('numOfChannels', 0);
        numOfChannels = 0;
        if(debug) console.log(numOfChannels);
	}
);

$('#lnkCustomFilters').bind(
	'click', function() {
		$('*').removeClass('selected');
		$(this).addClass('selected');
		hideMenus();
		$('#customFilters').show();
		$('#customFilters *').show();
		$('#filterFields * ').hide();
		$('#0, #0 *').show();
	}
);

$('SELECT').on('change',function(){
	$('#filterFields * ').hide();
	$('#' + $(this).attr('value') + ', ' + '#' + $(this).attr('value') + ' *').show();
});


$('#lnkEnableButtons').bind(
	'click', function() {
		$('*').removeClass('selected');
		$(this).addClass('selected');
		hideMenus();
		$('#controls').show();
		$('#controls *').show();
	}
);

$('#lnkHidden').bind(
	'click', function(){
		$('*').removeClass('selected');
		$(this).addClass('selected');
		hideMenus();
		$('#hidden').show();
		$('#hidden *').show();
	}
);

$('#lnkOtherOptions').bind(
	'click', function(){
		$('*').removeClass('selected');
		$(this).addClass('selected');
		hideMenus();
		$('#otherOptions').show();
		$('#otherOptions *').show();
	}
);


$('#clearSync').click(
	function(){
		chrome.storage.sync.clear();
		console.log('cleared');
	}
);

$('#printSync').click(
	function(){
		printSync('a');
	}
);

$('#lnkRecordings').bind(
	'click', function() {
		$('*').removeClass('selected');
		$(this).addClass('selected');
		hideMenus();
		$('#recordings').show();
		$('#recordings *').show();
	}
);

$('#lnkHelp').bind(
	'click', function() {
		$('*').removeClass('selected');
		$(this).addClass('selected');
		hideMenus();
		$('#help').show();
		$('#help *').show();
	}
);

$('#lnkRecordings').bind(
	'click', function() {
		$('*').removeClass('selected');
		$(this).addClass('selected');
		hideMenus();
		$('#recordings').show();
		$('#recordings *').show();
	}
);

$('#lnkHelp').bind(
	'click', function() {
		$('*').removeClass('selected');
		$(this).addClass('selected');
		hideMenus();
		$('#help').show();
		$('#help *').show();
	}
);

$('#lnkEnableButtons').click();