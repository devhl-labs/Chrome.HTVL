//this version is published to testers only, no longer used
chrome.management.setEnabled('hkmkpjagnahjgfdkjolfdnlanmamifof', false);

//previous version that is no longer published, no longer used
chrome.management.setEnabled('gnbeokkohplojcckboakfdippdeclilo', false);

//offline dev version
chrome.management.setEnabled('kdojmcccbhhadlknkjnomcpmkbhlfhbm', true);

//online published version
chrome.management.setEnabled('emahdgfobodhknccbigjmnhpgihmmjbf', false);









