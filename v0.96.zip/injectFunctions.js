var debug = true;

var keys = [
	'lnkHd', 
	'lnkFavorites',
	'lnkRemoveAllFavorites',
	'lnkHideChannels',
	'lnkLast',
	'lnkRecording',
	'lnkMostWatched',
	'lnkMovies',
	'lnkSports',
	'lnkKids',
	
	'recording',
];



///////////////////PROCESS EVERY CHANNEL AND MAKE CHANGES/////////////
function init(){
	//small css changes
	$('.hover-add').css('border-left', '0px');
	$('.hover-remove').css('border-left', '0px');
	$('.channels').css({'min-height': '1000px'});
	$('.viewport').css({'min-height': '1000px'});
	
	chrome.storage.sync.get(
		'strHidden', function(result){
			//loop through all channels
			var $channels = $('.channel').not('.processed');
			var $hoverWatch;
			$channels.each(
				function(x){
					$hoverWatch = $(this).find('.channel-button-hover');
					$hoverWatch.attr('style', 'width: 283px');		
					var arr = result['strHidden'].split(';');
					var booFound = false;
					for(var i = arr.length - 1; i >= 0; --i){
						if(this.id == arr[i]){
							booFound = true;
							$hoverWatch.attr('style', 'width: 283px; background-color: DarkGray;');
							$(this).addClass('HideMe');
							break;
						}
					}
					if(!booFound){
						$hoverWatch.attr('style', 'width: 283px;');
						$(this).addClass('ShowMe');				
					}
					createHideMe($(this), $hoverWatch);
					createUnHide($(this), $hoverWatch);
					$(this).addClass("processed");
				}
			);
		}
	);
	if(debug) console.log('initialized');
}

function createHideMe($channel, $hoverWatch){
	var channel = $channel[0];
	var hoverWatch = $hoverWatch[0];
	var lnk=document.createElement('a');
	lnk.innerHTML = 'Hide Me!';
	lnk.setAttribute('style', 'display: block; width: 41px; cursor: pointer;');
	lnk.setAttribute('class', 'hideChannels');
	lnk.onclick=function(){
		hoverWatch.setAttribute('style', 'background-color: DarkGray; width: 283px');
		channel.className = channel.className.replace(" ShowMe", " ");
		channel.className = channel.className.replace(" HideMe", " ");		
		channel.className = channel.className + "HideMe";
		/*
		if(!localStorage['htvlHide']){localStorage['htvlHide'] = strHiddenChannels;}
		localStorage['htvlHide'] = localStorage['htvlHide'].replace(channel.id + ';', '');
		localStorage['htvlHide'] += channel.id + ";";
		*/
		
		chrome.storage.sync.get(
			'strHidden', function(result){
				var arr = result['strHidden'].split(';');
				var booFound = false;
				for(var i = arr.length - 1; i >= 0; --i){
					if(channel.id == arr[i]){
						if(debug) console.log('its already there');
						booFound = true;
						break;
					}
				}
				if(!booFound){
					if(debug)console.log('adding channel to string');
					if(arr[arr.length - 1] == '') arr.pop();
					arr.push(channel.id);
					//var str = arr.join(';');
					setKey('strHidden', arr.join(';'));					
				}		
			}
		);
	};
	hoverWatch.appendChild(lnk);
}

function createUnHide($channel, $hoverWatch){
	var channel = $channel[0];
	var hoverWatch = $hoverWatch[0];
	var lnk=document.createElement('a');
	lnk.innerHTML = 'Unhide Me';
	lnk.setAttribute('style', 'display: block; width: 41px; cursor: pointer;');
	lnk.setAttribute('class', 'unHideChannels');
	lnk.onclick=function(){
		//if(!localStorage['htvlHide']){localStorage['htvlHide'] = strHiddenChannels;}
		//localStorage['htvlHide']=localStorage['htvlHide'].replace(channel.id + ";", '');
		hoverWatch.setAttribute('style', 'width: 283px;');
		channel.className = channel.className.replace(" ShowMe", " ");
		channel.className = channel.className.replace(" HideMe", " ");		
		channel.className = channel.className + "ShowMe";
		
		chrome.storage.sync.get(
			'strHidden', function(result){
				var arr = result['strHidden'].split(';');
				var booFound = false;
				for(var i = arr.length - 1; i >= 0; --i){
					if(channel.id == arr[i]){
						if(debug) console.log('removing from array');
						arr.splice(i);
						setKey('strHidden', arr.join(';'));
						break;
					}
				}		
			}
		);		
		
		
	};
	hoverWatch.appendChild(lnk);
}




//////////////////SUPPORTING FUNCTIONS///////////////////////////////
function sortChannels(){
	if(localStorage['htvlUnsorted'] == 'unsorted'){
		$('.channel').tsort({attr:'id'});
		localStorage['htvlUnsorted'] = 'sorted';
	}
}

function clearFilters(){
	try{
		$('.selected[data-filter]')[0].click();
	}catch(e){
	}
	$('.selected').removeClass('selected');
}

function showHidden(){
	$('.channel').show();
	sortChannels();
}

function hideObjects(){
	//lets hide the appropriate channels
	chrome.storage.sync.get(
		null, function (items) {
			for(var key in items){
				if(items[key] == 0) $('#' + key).hide();
			}
		}
	);
}

function watchChannelListener(){
	var $hoverWatch = $('.hover-watch');
	$hoverWatch.live(
		"click", function() {
			var $channel = $(this).parent().parent();

			//record last watched channel
			chrome.storage.sync.get(
				'last', function (items) {
					var str = items['last'];
					if(str === undefined) str = '';
					str = str.replace($channel.attr('id') + ';', '');
					str = str + $channel.attr('id') + ';';
					setKey('last', str);
				}
			);
			setKey('lastDate', Date());
	
			//record most watched
			chrome.storage.sync.get(
				'mostWatched', function (items) {
					if(items['mostWatched'] === undefined){
						setKey('mostWatched', $channel.attr('id') + '=1');
					}else{
						var str = '';
						arr = items['mostWatched'].toString().split(';');
						var arr2;
						var boo = false;
						for(var i = arr.length - 1; i >= 0; --i){
							arr2 = arr[i].split('=');
							if(arr2[0] == $channel.attr('id')){
								var num = Number(arr2[1]) + 1;
								arr2[1] = num;
								str = arr2.join('=');
								arr[i] = str;
								str = arr.join(';');
								setKey('mostWatched', str);
								boo = true;
							}
						}
						if(!boo){
							//console.log('channel is not in the array');
							arr.push($channel.attr('id') + '=1')
							str = arr.join(';');
							setKey('mostWatched', str);
						}	
					}
				}
			);	
			if(debug)console.log('end hover watch listener');
		}
	)
}

function hideRows(){
	chrome.storage.sync.get(
		'strHidden', function(result){
			var arr = result['strHidden'].split(';');
			for (var i = arr.length - 1; i >= 0; --i) {	
				$('#' + arr[i]).hide();
			}
		}
	);
}

function checkLastWatchedDate(){
	if(!localStorage['htvlLastDate']){localStorage['htvlLastDate']=Date();}
	if(!localStorage['htvlLast']){localStorage['htvlLast']='';}	
	
	var intOneHour = 60 * 60 * 1000;
	var dateOld = new Date(localStorage['htvlLastDate']);
	var dateNow = new Date();
	
	if(dateNow - dateOld > 4 * intOneHour){
		localStorage['htvlLast']='';
	}
}

function setSortOrder(){
	$('#lnkHideChannels').attr('sortorder', '0');
	$('#lnkLast').attr('sortorder', '1');
	$('#lnkRecording').attr('sortorder', '2');
	$('#lnkMostWatched').attr('sortorder', '3');
	$('#lnkHd').attr('sortorder', '4');
	$('#lnkFavorites').attr('sortorder', '5');
	$('#lnkRemoveAllFavorites').attr('sortorder', '6');
	$('#lnkPrintSync').attr('sortorder', '98');
	$('#lnkClearSync').attr('sortorder', '99');
}


/////////////////CHROME SYNC MANAGEMENT/////////////////////////////
function setKey(key, value){
	var obj = {};
	obj[key] = value;
	chrome.storage.sync.set(obj);
}

function setDefaults(){
	chrome.storage.sync.get(
		keys, function(result){
			var boo = false;
			keys.forEach(
				function(key){
					if(key != 'recording' && result[key] === undefined){
						setKey(key, '1');
						if(!boo) localStorage['htvlNumOfChannels'] = 0;
						boo = true;
					}
				}
			)
		}
	);
	
	var strHidden = '329;602;028;831;995;095;996;096;999;099;063;881;690;192;112;107;324;037;889;540;498;868;041;989;592;636;114;583;726;058;115;103;029;714;713;715;855;855;922;654;588;732;661;159;645;647;480;146;053;054;570;817;060;122;941;942;615;007;846;644;020;104;105;660;643;113;062;593;880;125;135;641;039;575;869;287;877;046;622;998;098;150;986;701;702;703;704;705;706;851;712;006;005;585;719;730;047;664;291;597;799;106;720;721;722;670;056;820;044;839;231;584;627;032;857;148;009;824;725;567;771;772;773;774;775;776;777;778;779;682;780;781;782;783;784;669;789;790;003;849;651;066;116;157;301;311;491;801;487;488;901;785;490;043;838;875;038;577;579;064;055;717;023;088;808;130;993;111;164;501;167;502;072;543;069;025;184;587;992;027;204;119;802;845;004;021;320;322;233;319;437;413;418;412;422;447;407;448;424;449;427;450;429;417;431;416;433;415;435;414;401;421;439;423;441;425;443;411;445;410;426;409;430;402;434;408;438;403;442;446;432;419;406;420;405;436;428;444;440;404;176;738;327;321;366;151;499;315;812;052;049;605;601;328;863;749;002;848;733;860;246;861;263;734;871;109;739;061;616;330;607;728;155;123;626;549;544;882;662;663;016;806;679;657;637;635;655;110;872;696;341;346;342;340;238;339;987;089;283;347;888;990;988;191;694;736;030;693;128;370;372;375;374;371;369;248;373;571;623;031;829;033;826;297;036;008;751;752;753;754;755;756;757;758;759;620;633;547;735;652;040;837;604;566;760;325;350;351;352;787;787;862;034;825;065;141;991;045;035;680;695;612;618;100;674;621;057;822;564;562;189;010;823;559;870;050;545;594;649;611;011;208;811;015;805;117;051;026;800;561;018;017;019;807;108;013;813;668;012;563;022;014;804;294;689;198;196;024;803;565;981;960;970;186;550;001;548;542;691;850';
	chrome.storage.sync.get(
		'strHidden', function(result){
			if(result['strHidden'] === undefined){
				setKey('strHidden', strHidden);
			}
		}
	);
	
	chrome.storage.sync.get(
		null, function (result) {
			setCustomFilters(result, '0', '1', 'College', 'College Baseball');
			setCustomFilters(result, '1', '1', 'MLB', 'MLB Baseball');
			setCustomFilters(result, '2', '1', 'NBA', 'NBA Playoff');
			setCustomFilters(result, '3', '1', 'NHL', 'Stanley Cup Playoff;Stanley Cup Final');
			setCustomFilters(result, '4', '1', 'NFL', 'NFL Draft');
			setCustomFilters(result, '9', '0', 'test', 'Weatherscan;Paid Programming;CNN Newsroom;Community Channel');
		}
	);
}

function setCustomFilters(result, b, enable, title, terms){
	if(result['b' + b] === undefined && 
	result['b' + b + 'title'] === undefined && 
	result['b' + b + 'terms'] === undefined){
		if(debug) console.log('setting b' + b + ' default');
		setKey('b' + b, enable);
		setKey('b' + b + 'title', title);
		setKey('b' + b + 'terms', terms);
	}
}

function printSync(detail){
	//for debugging only
	//just prints the sync values to the console
	//printSync();
	//printSync('true');
	if(typeof detail === 'undefined'){
		chrome.storage.sync.get(null, function (data) { console.info(data) });
	}else{
		chrome.storage.sync.get(
			null, function (items) {
				for(var key in items){
					console.log(key + ' ' + items[key]);
				}
			}
		);
	}
}


