var strHiddenChannels='329;602;028;831;995;095;996;096;999;099;063;881;690;192;112;107;324;037;889;540;498;868;041;989;592;636;114;583;726;058;115;103;029;714;713;715;855;855;922;654;588;732;661;159;645;647;480;146;053;054;570;817;060;122;941;942;615;007;846;644;020;104;105;660;643;113;062;593;880;125;135;641;039;575;869;287;877;046;622;998;098;150;986;701;702;703;704;705;706;851;712;006;005;585;719;730;047;664;291;597;799;106;720;721;722;670;056;820;044;839;231;584;627;032;857;148;009;824;725;567;771;772;773;774;775;776;777;778;779;682;780;781;782;783;784;669;789;790;003;849;651;066;116;157;301;311;491;801;487;488;901;785;490;043;838;875;038;577;579;064;055;717;023;088;808;130;993;111;164;501;167;502;072;543;069;025;184;587;992;027;204;119;802;845;004;021;320;322;233;319;437;413;418;412;422;447;407;448;424;449;427;450;429;417;431;416;433;415;435;414;401;421;439;423;441;425;443;411;445;410;426;409;430;402;434;408;438;403;442;446;432;419;406;420;405;436;428;444;440;404;176;738;327;321;366;151;499;315;812;052;049;605;601;328;863;749;002;848;733;860;246;861;263;734;871;109;739;061;616;330;607;728;155;123;626;549;544;882;662;663;016;806;679;657;637;635;655;110;872;696;341;346;342;340;238;339;987;089;283;347;888;990;988;191;694;736;030;693;128;370;372;375;374;371;369;248;373;571;623;031;829;033;826;297;036;008;751;752;753;754;755;756;757;758;759;620;633;547;735;652;040;837;604;566;760;325;350;351;352;787;787;862;034;825;065;141;991;045;035;680;695;612;618;100;674;621;057;822;564;562;189;010;823;559;870;050;545;594;649;611;011;208;811;015;805;117;051;026;800;561;018;017;019;807;108;013;813;668;012;563;022;014;804;294;689;198;196;024;803;565;981;960;970;186;550;001;548;542;691;850;';
if(!localStorage['xfinityHide']){localStorage['xfinityHide']=strHiddenChannels;}

//Create the container to hold my buttons
var aside = document.getElementsByClassName('options')[0];
var divContainer = document.createElement('div');
divContainer.setAttribute('class', 'option-filters');
aside.insertBefore(divContainer, aside.childNodes[4]);
var hr = document.createElement('hr');
divContainer.appendChild(hr);

//remove favorites
var lnk = document.createElement('a');
lnk.innerHTML = 'Remove All Favorites';
lnk.setAttribute('class',  'button filter');
divContainer.appendChild(lnk);
lnk.onclick=function(){
	init();
	var style;
	var display = '';
	var hoverRemove = document.getElementsByClassName('hover-remove');
	for (var i = hoverRemove.length -1; i >= 0; --i){
		style = window.getComputedStyle(hoverRemove[i]);
		display = style.getPropertyValue('display');
		if(display == 'block'){
			hoverRemove[i].click();
		}
	}
}


//hide channels
var lnk = document.createElement('a');
lnk.id='lnkHideMe';
lnk.innerHTML = 'Hide Channels'
lnk.setAttribute('class',  'button filter');
divContainer.appendChild(lnk);
lnk.onclick = function(){
	init();
	document.getElementById('lnkShowMe').click();
	
	var channels = document.getElementsByClassName('channel');
	var channel;
	var hoverWatch;
	
	for(var i = channels.length -1; i >= 0; --i){
		channel = channels[i];
		hoverWatch = channel.childNodes[3];
		if(localStorage['xfinityHide'].indexOf(channel.id) > -1){
			hoverWatch.setAttribute('style', 'width: 283px; background-color: DarkGray;');
			channel.classList.remove('ShowMe');
			channel.classList.remove('HideMe');
			channel.className = channel.className + " HideMe";
		}else{
			hoverWatch.setAttribute('style', 'width: 283px;');
			channel.classList.remove('ShowMe');
			channel.classList.remove('HideMe');
			channel.className = channel.className + " ShowMe";
		}
	}
	hideRows();
}

//show hidden
lnk = document.createElement('a');
lnk.innerHTML='Show Hidden';
lnk.id='lnkShowMe';
lnk.setAttribute('class', 'button filter');
divContainer.appendChild(lnk);
lnk.onclick=function(){
	init();
	$('.channel').show();
	$('.watchedLast').sortElements(function(a, b){
		return $(a).attr('id') > $(b).attr('id') ? 1 : -1;
	});
}

//last
lnk = document.createElement('a');
lnk.innerHTML='Last';
lnk.setAttribute('class', 'button filter');
divContainer.appendChild(lnk);
lnk.onclick = function(){
	init();
	//populate last watched class
	$('.watchedLast').removeClass('watchedLast');
	var channel;
	var $channel;
	if(localStorage['xfinityLast']){
		var arrLast = localStorage['xfinityLast'].split(';');
		for (var i = arrLast.length - 1; i > 0; i--) {
			$channel = $('#' + arrLast[i-1]);
			if(!$channel.hasClass('watchedLast')){
				$('#' + arrLast[i-1]).addClass('watchedLast');
				channel = $('#' + arrLast[i-1])[0]
				channel.setAttribute('watchedLast', i);
			}
		}
	}
	$('.channel').hide();
	$('.watchedLast').show();
	$('.watchedLast').sortElements(function(a, b){
		return $(a).attr('watchedLast') < $(b).attr('watchedLast') ? 1 : -1;
	});
}

//Create branding link
var lnk = document.createElement('a');
lnk.innerHTML='More From Developer';
lnk.setAttribute('class', 'button filter');
lnk.href=chrome.extension.getURL('appsFromDeveloper/appsFromDeveloper.html');
lnk.target='_blank';
divContainer.appendChild(lnk);

//create separator 
hr = document.createElement('hr');
divContainer.appendChild(hr);

//sports
var lnkCustomFilter;
var version = 0.7
if(!localStorage['xfinityFilterVersion']){localStorage['xfinityFilterVersion'] = version;}
if(!localStorage['xfinityFilterUpdates']){localStorage['xfinityFilterUpdates'] = 'True';}
if(localStorage['xfinityFilterUpdates'] == 'True'){
	localStorage['xfinityFilterVersion'] = version;
	localStorage['xfinityFilters']=
		'NFL::NFL Total Access::NFL Draft;'	+
		'NHL::Stanley Cup Playoff;' +	
		'NCAAM::College Basketball;' +	
		'NBA::NBA Playoff;' +	
		'MLB::MLB Baseball::MLB Tonight;'
	;
}

var sports=localStorage['xfinityFilters'].split(';');
for(i = sports.length - 2; i >= 0; --i){
	var terms = sports[i].split('::');
	lnk=document.createElement('a');
	lnk.innerHTML=terms[0];
	lnk.setAttribute('class', 'button filter');
	lnk.onclick=function(){
		init();
		var channel;
		if($('.' + this.innerHTML.replace(' ','')).length>0){
			//the user has selected this filter before
			//simply show appropraite class
			$('.' + this.innerHTML.replace(' ','')).show();
			$('.no' + this.innerHTML.replace(' ','')).hide();
			$('.HideMe').hide();
		}else{
			//the user has not selected this filter yet
			//classes still need to be added to channels
			document.getElementById('lnkShowMe').click();
			document.getElementById('lnkHideMe').click();				
			var sports=localStorage['xfinityFilters'].split(';');
			for(var a = sports.length -1; a >= 0; --a){
				if(sports[a].substring(0, this.innerHTML.length)==this.innerHTML){
					//at this point, sports[a] is the entire string for one sport
					//example NHL::Stanley Cup Playoffs; Some other hockey value
					//the next line strips off sports[0] which is the title of the sport NHL, NFL, ect
					sports[a] = sports[a].substring(this.innerHTML.length + 2);
					var terms = sports[a].split('::');
					//now lets scroll through all the shows in the guide and
					//compare show's title to values in the array terms
					var shows = document.getElementsByClassName('listing-entity');
					for(var b = shows.length - 1; b >= 0; --b){
						channel = shows[b].parentNode.parentNode;
						if($.inArray(shows[b].innerHTML, terms) != -1){
							//console.log('we have a match!');
							if(!channel.classList.contains(this.innerHTML.replace(' ', ''))){
								if(!channel.classList.contains('HideMe')){
									channel.setAttribute('style', 'display: block;');
								}
								channel.classList.remove('no' + this.innerHTML.replace(' ', ''));
								channel.className =
									channel.className + ' ' + this.innerHTML.replace(' ','');
							}
						}else{
							//this show does not match the filter, but another might, so lets check the parents class
							if(!channel.classList.contains(this.innerHTML.replace(' ',''))){
								//console.log('no match');
								channel.setAttribute('style', 'display: none;');
								if(!channel.classList.contains('no' + this.innerHTML.replace(' ',''))){
									channel.className =
										channel.className + ' no' + this.innerHTML.replace(' ','');
								}
							}
						}
					}			
				}
			}
		}
	}
	var div = document.getElementsByClassName('option-filters')[1];
	div.appendChild(lnk);
} 

function init(){
	//I would like to do most of the below code when the page is finished loading
	//but the dom is finished loading before the channels
	//running the below on the button press is a way of making sure all of the 
	//channels are loaded completely.
	
	if($('.xfinityHideTvListings').length > 0){return;}
	
	//small css changes
	$('.hover-add').css('border-left', '0px');
	$('.hover-remove').css('border-left', '0px');
	$('.channels').css({'min-height': '1000px'});
	$('.viewport').css({'min=height': '1000px'});
	
	//loop through all channels
	var channels = document.getElementsByClassName('channel')
	var hoverWatch;
	for(var i = channels.length -1; i >= 0; --i){
		hoverWatch = channels[i].childNodes[3];	
		//inject CSS to prepare for new buttons
		if(localStorage['xfinityHide'].indexOf(channels[i].id)>-1){
			hoverWatch.setAttribute('style', 'width: 283px; background-color: DarkGray;');
		}else{
			hoverWatch.setAttribute('style', 'width: 283px;');
		}
		createHideMe(channels[i], hoverWatch);
		createUnHide(channels[i], hoverWatch);	
	}
	
	
	watchChannelListener();
	checkLastWatchedDate();
	$('body').addClass('xfinityHideTvListings');
};



function checkLastWatchedDate(){
	if(!localStorage['xfinityLastDate']){localStorage['xfinityLastDate']=Date();}
	if(!localStorage['xfinityLast']){localStorage['xfinityLast']='';}	
	
	var intOneHour = 60 * 60 * 1000;
	var dateOld = new Date(localStorage['xfinityLastDate']);
	var dateNow = new Date();
	
	if(dateNow - dateOld > 4 * intOneHour){
		localStorage['xfinityLast']='';
	}
}


function watchChannelListener(){
	var $hoverWatch = $('.hover-watch');
	$hoverWatch.bind(
		"click", function() {
			var $channel = $(this).parent().parent();
			localStorage['xfinityLastDate']=Date();
			//The order if the list in local storage is important
			//remove the old entry and make a new one
			localStorage['xfinityLast'] = localStorage['xfinityLast'].replace($channel.attr('id') + ';', '');
			localStorage['xfinityLast'] += $channel.attr('id') + ";";
			$channel.addClass('watchedLast');
		}
	)
}

function createHideMe(channel, hoverWatch){
	var lnk=document.createElement('a');
	lnk.innerHTML = 'Hide Me!';
	lnk.setAttribute('style', 'display: block; width: 41px; cursor: pointer;');
	lnk.setAttribute('class', 'hideChannels');
	lnk.onclick=function(){
		hoverWatch.setAttribute('style', 'background-color: DarkGray; width: 283px');
		channel.className = channel.className.replace(" ShowMe", " ");
		channel.className = channel.className.replace(" HideMe", " ");		
		channel.className = channel.className + "HideMe";
		if(!localStorage['xfinityHide']){localStorage['xfinityHide'] = strHiddenChannels;}
		localStorage['xfinityHide'] = localStorage['xfinityHide'].replace(channel.id + ';', '');
		localStorage['xfinityHide'] += channel.id + ";";
	};
	hoverWatch.appendChild(lnk);
}

function createUnHide(channel, hoverWatch){
	var lnk=document.createElement('a');
	lnk.innerHTML = 'Unhide Me';
	lnk.setAttribute('style', 'display: block; width: 41px; cursor: pointer;');
	lnk.setAttribute('class', 'unHideChannels');
	lnk.onclick=function(){
		if(!localStorage['xfinityHide']){localStorage['xfinityHide']=strHiddenChannels;}
		localStorage['xfinityHide']=localStorage['xfinityHide'].replace(channel.id + ";", '');
		hoverWatch.setAttribute('style', 'width: 283px;');
		channel.className = channel.className.replace(" ShowMe", " ");
		channel.className = channel.className.replace(" HideMe", " ");		
		channel.className = channel.className + "ShowMe";
	};
	hoverWatch.appendChild(lnk);
}


function hideRows(){
	if(localStorage['xfinityHide']){
		var arr = localStorage['xfinityHide'].split(';');
		for (var i = arr.length - 1; i >= 0; --i) {	
			$('#' + arr[i]).hide();
		}
	}
}


/* http://james.padolsey.com/javascript/sorting-elements-with-jquery/
 *  
 *
 * jQuery.fn.sortElements
 * --------------
 * @param Function comparator:
 *   Exactly the same behaviour as [1,2,3].sort(comparator)
 *   
 * @param Function getSortable
 *   A function that should return the element that is
 *   to be sorted. The comparator will run on the
 *   current collection, but you may want the actual
 *   resulting sort to occur on a parent or another
 *   associated element.
 *   
 *   E.g. $('td').sortElements(comparator, function(){
 *      return this.parentNode; 
 *   })
 *   
 *   The <td>'s parent (<tr>) will be sorted instead
 *   of the <td> itself.
 */
jQuery.fn.sortElements = (function(){
 
    var sort = [].sort;
 
    return function(comparator, getSortable) {
 
        getSortable = getSortable || function(){return this;};
 
        var placements = this.map(function(){
 
            var sortElement = getSortable.call(this),
                parentNode = sortElement.parentNode,
 
                // Since the element itself will change position, we have
                // to have some way of storing its original position in
                // the DOM. The easiest way is to have a 'flag' node:
                nextSibling = parentNode.insertBefore(
                    document.createTextNode(''),
                    sortElement.nextSibling
                );
 
            return function() {
 
                if (parentNode === this) {
                    throw new Error(
                        "You can't sort elements if any one is a descendant of another."
                    );
                }
 
                // Insert before flag:
                parentNode.insertBefore(this, nextSibling);
                // Remove flag:
                parentNode.removeChild(nextSibling);
 
            };
 
        });
 
        return sort.call(this, comparator).each(function(i){
            placements[i].call(getSortable.call(this));
        });
 
    };
 
})();